#!/bin/sh

DIR="$HOME/Imagens"
mkdir -p "$DIR"

FILE="$DIR/$(date '+%Y-%m-%d_%H-%M-%S').png"

# selecionar área
maim -s "$FILE"

# copia para clipboard
xclip -selection clipboard -t image/png < "$FILE"

# notificação
notify-send "Screenshot" "Área capturada ✓"
