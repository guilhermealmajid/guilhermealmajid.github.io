# Fios & Afeto — Landing Page de Crochê

Landing page estática feita com React + Vite.

## Esta versão não possui

- banco de dados
- Supabase
- login
- área administrativa
- dashboard
- backend
- localStorage para catálogo

O catálogo é estático e fica em `src/data/mock.js`. Para alterar produtos, preços, categorias, textos ou imagens, edite esse arquivo.

## Rodar no Arch Linux

```bash
npm install
npm run dev
```

Depois abra o endereço mostrado pelo Vite, normalmente:

```text
http://localhost:5173
```

## Gerar versão de produção

```bash
npm run build
npm run preview
```

## Estrutura principal

```text
src/
├── components/
│   ├── Layout.jsx
│   └── ProductCard.jsx
├── data/
│   └── mock.js       # produtos e categorias
├── pages/
│   ├── Home.jsx
│   ├── Products.jsx
│   ├── Product.jsx
│   └── About.jsx
├── App.jsx
├── index.css
└── main.jsx
```

O WhatsApp configurado atualmente é `+55 34 99888-4407`.
