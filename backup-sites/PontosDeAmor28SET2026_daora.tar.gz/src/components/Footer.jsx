import React from 'react'
import { Heart, MessageCircle, ArrowUp, ShieldCheck } from 'lucide-react'
import { BRAND, buildWhatsAppUrl } from '../data/mock'

function InstagramIcon({ size = 18 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  )
}

// Função para manter o ano do rodapé sempre atualizado dinamicamente
function getCurrentYear() {
  return new Date().getFullYear()
}

export default function Footer() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <footer className="footer-wrap">
      <div className="container">
        <div className="footer-top-grid">
          {/* Brand Info */}
          <div className="footer-col">
            <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
              <img
                src={BRAND.logo}
                alt={BRAND.name}
                style={{
                  width: '44px',
                  height: '44px',
                  borderRadius: '50%',
                  objectFit: 'cover',
                  border: '2px solid var(--accent)',
                  boxShadow: 'var(--shadow-sm)',
                  flexShrink: 0
                }}
              />
              <div>
                <span className="brand-text" style={{ fontSize: '1.25rem' }}>{BRAND.name}</span>
                <span className="brand-subtext">{BRAND.subname || 'by Layla Almeida'}</span>
              </div>
            </div>
            <p style={{ marginBottom: '18px' }}>
              {BRAND.slogan}. Peças exclusivas tecidas ponto a ponto com fios nobres e muito
              cuidado para o seu lar e momentos inesquecíveis.
            </p>
            <div style={{ display: 'flex', gap: '10px' }}>
              <a
                href={buildWhatsAppUrl(`Olá ${BRAND.artisan}! Vim pelo rodapé do site.`)}
                target="_blank"
                rel="noreferrer"
                className="theme-toggle-btn"
                style={{ width: '38px', height: '38px' }}
                aria-label="WhatsApp"
              >
                <MessageCircle size={18} />
              </a>
              <a
                href={BRAND.instagramUrl || `https://www.instagram.com/pontosdeamorlayla/`}
                target="_blank"
                rel="noreferrer"
                className="theme-toggle-btn"
                style={{ width: '38px', height: '38px' }}
                aria-label="Instagram"
              >
                <InstagramIcon size={18} />
              </a>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="footer-col">
            <h4>Navegação</h4>
            <ul className="footer-links-list">
              <li><a href="/#hero">Início</a></li>
              <li><a href="/#diferenciais">Diferenciais</a></li>
              <li><a href="/#colecao">Coleção de Peças</a></li>
              <li><a href="/#personalizado">Simulador de Encomenda</a></li>
              <li><a href="/#processo">Como Funciona</a></li>
              <li><a href="/#depoimentos">Depoimentos</a></li>
              <li><a href="/#faq">Dúvidas Frequentes</a></li>
            </ul>
          </div>

          {/* Categories */}
          <div className="footer-col">
            <h4>Categorias</h4>
            <ul className="footer-links-list">
              <li><a href="/#colecao">Bolsas Artesanais</a></li>
              <li><a href="/#colecao">Moda Praia</a></li>
              <li><a href="/#colecao">Sousplat & Mesa Posta</a></li>
              <li><a href="/#personalizado">Peças Personalizadas</a></li>
            </ul>
          </div>

          {/* Contact & Hours */}
          <div className="footer-col">
            <h4>Atendimento</h4>
            <p style={{ marginBottom: '8px' }}>
              <b>Artesã:</b> {BRAND.artisan}
            </p>
            <p style={{ marginBottom: '8px' }}>
              <b>WhatsApp:</b>{' '}
              <a
                href={buildWhatsAppUrl('Olá!')}
                target="_blank"
                rel="noreferrer"
                style={{ color: 'var(--whatsapp)', fontWeight: 600 }}
              >
                {BRAND.formattedPhone}
              </a>
            </p>
            <p style={{ marginBottom: '8px' }}>
              <b>Horário:</b> {BRAND.workingHours}
            </p>
            <p style={{ marginBottom: '14px' }}>
              <b>Local:</b> {BRAND.location}
            </p>

            <div style={{ display: 'flex', alignItems: 'center', gap: '6px', fontSize: '0.84rem', color: 'var(--text-muted)' }}>
              <ShieldCheck size={16} style={{ color: 'var(--accent)' }} />
              <span>Pagamento Seguro via Pix e Cartão</span>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="footer-bottom-bar">
          <div>
            © {getCurrentYear()} {BRAND.name}. Feito à mão com afeto. Todos os direitos reservados.
          </div>

          <button
            onClick={scrollToTop}
            className="btn-outline"
            style={{ padding: '8px 18px', fontSize: '0.84rem' }}
          >
            <span>Voltar ao topo</span>
            <ArrowUp size={14} />
          </button>
        </div>
      </div>
    </footer>
  )
}
