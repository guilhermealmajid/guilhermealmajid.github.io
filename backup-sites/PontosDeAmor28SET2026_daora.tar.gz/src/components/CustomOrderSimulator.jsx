import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Sparkles, MessageCircle, Send, CheckCircle2 } from 'lucide-react'
import { BRAND, buildWhatsAppUrl } from '../data/mock'

const pieceOptions = [
  'Bolsa Tiracolo com Strass & Flor de Pérolas',
  'Bolsa Tiracolo Cacau com Tassel',
  'Mini Bag / Porta-Celular em Crochê',
  'Conjunto Moda Praia (Biquíni & Saia de Franjas)',
  'Top Cropped Moda Praia Arrastão',
  'Jogo de Sousplat Tulipas da Primavera',
  'Jogo Sousplat & Porta-Copos Imperial Roxo',
  'Outro modelo sob medida'
]

const colorOptions = [
  'Mostarda / Ocre Solar',
  'Chocolate / Cacau Rústico',
  'Verde Esmeralda Tropical',
  'Roxo Imperial & Ametista',
  'Cru / Off-White Natural',
  'Quero enviar foto de referência'
]

const occasionOptions = [
  'Uso Próprio / Para Mim Mesma',
  'Viagem / Passeio de Férias & Praia',
  'Mesa Posta para Jantares e Família',
  'Presente Especial para Alguém Querido',
  'Ocasião Especial / Evento'
]

export default function CustomOrderSimulator() {
  const [selectedPiece, setSelectedPiece] = useState(pieceOptions[0])
  const [selectedColor, setSelectedColor] = useState(colorOptions[0])
  const [selectedOccasion, setSelectedOccasion] = useState(occasionOptions[0])
  const [extraNotes, setExtraNotes] = useState('')

  const generatedMessage = `Olá ${BRAND.artisan}! Gostaria de solicitar um orçamento para uma encomenda personalizada no Ateliê ${BRAND.name}:
• Peça: ${selectedPiece}
• Paleta de Cores: ${selectedColor}
• Finalidade: ${selectedOccasion}${extraNotes ? `\n• Observações/Medidas: ${extraNotes}` : ''}

Poderia me informar a estimativa de valor e o prazo de confecção?`

  return (
    <section id="personalizado" className="section-padding simulator-section">
      <div className="container">
        <div style={{ textAlign: 'center' }}>
          <span className="section-label">
            <Sparkles size={16} />
            Sob Encomenda
          </span>
          <h2 className="section-title">Monte sua Encomenda Personalizada</h2>
          <p className="section-subtitle">
            Escolha as preferências da sua peça exclusiva e envie diretamente para a
            artesã no WhatsApp para receber o orçamento detalhado.
          </p>
        </div>

        <div className="simulator-box">
          {/* Interactive Form Controls */}
          <div className="simulator-form-col">
            {/* Step 1: Piece Type */}
            <div className="form-group">
              <label>1. O que você gostaria de encomendar?</label>
              <div className="custom-chips-grid">
                {pieceOptions.map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    onClick={() => setSelectedPiece(opt)}
                    className={`custom-chip ${selectedPiece === opt ? 'active' : ''}`}
                  >
                    {opt}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 2: Color Palette */}
            <div className="form-group">
              <label>2. Qual paleta de cores você prefere?</label>
              <div className="custom-chips-grid">
                {colorOptions.map((col) => (
                  <button
                    key={col}
                    type="button"
                    onClick={() => setSelectedColor(col)}
                    className={`custom-chip ${selectedColor === col ? 'active' : ''}`}
                  >
                    {col}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 3: Occasion */}
            <div className="form-group">
              <label>3. Para qual ocasião ou destino?</label>
              <div className="custom-chips-grid">
                {occasionOptions.map((occ) => (
                  <button
                    key={occ}
                    type="button"
                    onClick={() => setSelectedOccasion(occ)}
                    className={`custom-chip ${selectedOccasion === occ ? 'active' : ''}`}
                  >
                    {occ}
                  </button>
                ))}
              </div>
            </div>

            {/* Step 4: Notes */}
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label>4. Observações, medidas ou nome para bordar (opcional):</label>
              <input
                type="text"
                placeholder="Ex: Quero com bordado do nome 'Bento' e lacinho rosé..."
                value={extraNotes}
                onChange={(e) => setExtraNotes(e.target.value)}
                className="simulator-input"
              />
            </div>
          </div>

          {/* Live Preview Card */}
          <div className="preview-card-wrap">
            <div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '8px', color: 'var(--whatsapp)' }}>
                <CheckCircle2 size={20} />
                <span style={{ fontWeight: 700, fontSize: '0.94rem' }}>Prévia da Mensagem WhatsApp</span>
              </div>
              <p style={{ fontSize: '0.82rem', color: 'var(--text-muted)', marginTop: '4px' }}>
                Esta mensagem será enviada pronta para a artesã {BRAND.artisan}
              </p>

              <div className="preview-bubble-box">
                <div style={{ whiteSpace: 'pre-line', fontSize: '0.88rem' }}>
                  {generatedMessage}
                </div>
              </div>
            </div>

            <div style={{ marginTop: '28px' }}>
              <a
                href={buildWhatsAppUrl(generatedMessage)}
                target="_blank"
                rel="noreferrer"
                className="btn-whatsapp"
                style={{ width: '100%', padding: '16px' }}
              >
                <Send size={18} />
                <span>Enviar Encomenda no WhatsApp</span>
              </a>
              <span style={{ display: 'block', textAlign: 'center', fontSize: '0.78rem', color: 'var(--text-muted)', marginTop: '8px' }}>
                Atendimento rápido • Sem compromisso
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
