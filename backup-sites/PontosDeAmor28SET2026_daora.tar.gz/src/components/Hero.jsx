import React from "react";
import { motion } from "framer-motion";
import {
  Sparkles,
  MessageCircle,
  ArrowRight,
  Heart,
  Star,
  CheckCircle2,
} from "lucide-react";
import { BRAND, buildWhatsAppUrl } from "../data/mock";

export default function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15,
        delayChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 25 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" },
    },
  };

  return (
    <section id="hero" className="hero-section">
      <div className="container">
        <motion.div
          className="hero-grid"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          {/* Text Content */}
          <div className="hero-text-col">
            <motion.div variants={itemVariants} className="hero-pill">
              <Sparkles size={16} />
              <span>100% Feito à Mão • Peças Únicas</span>
            </motion.div>

            <motion.h1 variants={itemVariants} className="hero-title">
              Crochê que transforma fios em <em>afeto e elegância</em>.
            </motion.h1>

            <motion.p variants={itemVariants} className="hero-desc">
              Cada laçada é tecida com calma e carinho artesanal. Descubra a
              elegância de nossa moda praia em crochê, bolsas contemporâneas e
              itens de mesa posta que trazem o aconchego do trabalho feito à mão
              para a sua vida.
            </motion.p>

            <motion.div variants={itemVariants} className="hero-actions">
              <a href="#colecao" className="btn-primary">
                <span>Ver Coleção</span>
                <ArrowRight size={18} />
              </a>

              <a
                href={buildWhatsAppUrl(
                  `Olá ${BRAND.artisan}! Vi o site e quero conversar sobre uma encomenda personalizada de crochê.`,
                )}
                target="_blank"
                rel="noreferrer"
                className="btn-whatsapp"
              >
                <MessageCircle size={20} />
                <span>Pedir no WhatsApp</span>
              </a>
            </motion.div>

            {/* Quick Stats */}
            <motion.div variants={itemVariants} className="hero-stats-row">
              <div className="hero-stat-item">
                <b>+500</b>
                <span>Peças tecidas e entregues</span>
              </div>
              <div className="hero-stat-item">
                <b>100%</b>
                <span>Fios nobres e antialérgicos</span>
              </div>
              <div className="hero-stat-item">
                <b>5.0 ★</b>
                <span>Avaliação média dos clientes</span>
              </div>
            </motion.div>
          </div>

          {/* Hero Visual Media Showcase */}
          <motion.div className="hero-visual-wrapper" variants={itemVariants}>
            <motion.div
              className="hero-main-img-box"
              whileHover={{ scale: 1.02 }}
              transition={{ duration: 0.4 }}
            >
              <img
                src={BRAND.logo}
                alt="Pontos de Amor por Layla Almeida"
                className="hero-main-img"
                style={{ objectFit: "cover" }}
              />
            </motion.div>

            {/* Floating Badge 1: Brand & Artisan */}
            <motion.div
              className="hero-floating-badge badge-top-left"
              animate={{
                y: [0, -8, 0],
              }}
              transition={{
                duration: 4,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            >
              <img
                src={BRAND.logo}
                alt={BRAND.name}
                style={{
                  width: "38px",
                  height: "38px",
                  borderRadius: "50%",
                  objectFit: "cover",
                  border: "2px solid var(--accent)",
                  flexShrink: 0,
                }}
              />
              <div>
                <span
                  style={{
                    display: "block",
                    fontSize: "0.84rem",
                    fontWeight: 700,
                  }}
                >
                  {BRAND.name}
                </span>
                <span
                  style={{ fontSize: "0.74rem", color: "var(--text-muted)" }}
                >
                  {BRAND.subname || "by Layla Almeida"}
                </span>
              </div>
            </motion.div>

            {/* Floating Badge 2: Rating */}
            <motion.div
              className="hero-floating-badge badge-bottom-right"
              animate={{
                y: [0, 8, 0],
              }}
              transition={{
                duration: 4.5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: 0.5,
              }}
            >
              <div
                style={{
                  background: "#FEF3C7",
                  color: "#D97706",
                  width: "36px",
                  height: "36px",
                  borderRadius: "50%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Star size={18} fill="currentColor" />
              </div>
              <div>
                <span
                  style={{
                    display: "block",
                    fontSize: "0.82rem",
                    fontWeight: 700,
                  }}
                >
                  Clientes Encantadas
                </span>
                <span
                  style={{ fontSize: "0.74rem", color: "var(--text-muted)" }}
                >
                  Embalagem perfumada & afeto
                </span>
              </div>
            </motion.div>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
