import React, { useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { X, MessageCircle, Clock, Ruler, Sparkles, ShieldCheck } from 'lucide-react'
import { BRAND, buildWhatsAppUrl } from '../data/mock'

export default function ProductModal({ product, onClose }) {
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', handleKeyDown)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', handleKeyDown)
      document.body.style.overflow = 'auto'
    }
  }, [onClose])

  if (!product) return null

  const whatsappMsg = `Olá ${BRAND.artisan}! Gostei muito da peça *${product.name}* (${product.code} - R$ ${product.price.toFixed(2).replace('.', ',')}) no site. Gostaria de saber mais detalhes e prazo de entrega!`

  return (
    <AnimatePresence>
      <div className="modal-backdrop" onClick={onClose}>
        <motion.div
          className="modal-dialog"
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          transition={{ type: 'spring', damping: 25, stiffness: 300 }}
          onClick={(e) => e.stopPropagation()}
        >
          {/* Close button */}
          <button
            onClick={onClose}
            className="modal-close-btn"
            aria-label="Fechar detalhes"
          >
            <X size={20} />
          </button>

          {/* Left Column: Image */}
          <div className="modal-img-col">
            <img src={product.image} alt={product.name} />
            {product.badge && (
              <span className="product-badge-tag" style={{ position: 'absolute', top: 16, left: 16 }}>
                {product.badge}
              </span>
            )}
          </div>

          {/* Right Column: Info */}
          <div className="modal-info-col">
            <span className="product-category-lbl">{product.code}</span>
            <h2>{product.name}</h2>
            <p className="product-desc" style={{ WebkitLineClamp: 'unset', marginBottom: '14px' }}>
              {product.description}
            </p>

            <div className="modal-meta-list">
              <div className="modal-meta-item">
                <Ruler size={18} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                <span><b>Dimensões:</b> {product.dimensions || 'Sob consulta'}</span>
              </div>
              <div className="modal-meta-item">
                <Sparkles size={18} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                <span><b>Material:</b> {product.material || 'Fio 100% Algodão nobre'}</span>
              </div>
              <div className="modal-meta-item">
                <Clock size={18} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                <span><b>Produção:</b> {product.productionTime || 'Consulte no WhatsApp'}</span>
              </div>
              <div className="modal-meta-item">
                <ShieldCheck size={18} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                <span><b>Garantia:</b> Peça exclusiva, lavável com cuidados especiais</span>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px', marginBottom: '22px' }}>
              <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>Investimento:</span>
              <span className="product-price-val" style={{ fontSize: '2rem' }}>
                R$ {product.price.toFixed(2).replace('.', ',')}
              </span>
            </div>

            <a
              href={buildWhatsAppUrl(whatsappMsg)}
              target="_blank"
              rel="noreferrer"
              className="btn-whatsapp"
              style={{ width: '100%', padding: '14px' }}
            >
              <MessageCircle size={20} />
              <span>Pedir no WhatsApp</span>
            </a>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  )
}
