import React, { useState, useMemo } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Sparkles, Search, X } from 'lucide-react'
import { categories, products } from '../data/mock'
import ProductCard from './ProductCard'
import ProductModal from './ProductModal'

export default function CatalogoSection() {
  const [selectedCat, setSelectedCat] = useState('todos')
  const [searchQuery, setSearchQuery] = useState('')
  const [activeModalProduct, setActiveModalProduct] = useState(null)

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      const matchesCat = selectedCat === 'todos' || p.category === selectedCat
      const query = searchQuery.trim().toLowerCase()
      const matchesSearch =
        !query ||
        p.name.toLowerCase().includes(query) ||
        p.description.toLowerCase().includes(query) ||
        p.code.toLowerCase().includes(query)
      return matchesCat && matchesSearch
    })
  }, [selectedCat, searchQuery])

  return (
    <section id="colecao" className="section-padding">
      <div className="container" style={{ textAlign: 'center' }}>
        <span className="section-label">
          <Sparkles size={16} />
          Catálogo Artesanal
        </span>
        <h2 className="section-title">Coleção Feita Ponto a Ponto</h2>
        <p className="section-subtitle">
          Navegue pelas nossas peças em destaque ou use os filtros para encontrar a
          criação perfeita para presentear ou decorar.
        </p>

        {/* Filter and Search Bar */}
        <div className="catalog-header-bar">
          {/* Search Input */}
          <div className="catalog-search-wrap">
            <Search size={18} className="search-icon-left" />
            <input
              type="text"
              placeholder="Buscar por nome, modelo ou código..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="catalog-search-input"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="search-clear-right"
                aria-label="Limpar busca"
              >
                <X size={18} />
              </button>
            )}
          </div>

          {/* Category Filter Pills */}
          <div className="filter-pills-row">
            {categories.map((cat) => {
              const isActive = selectedCat === cat.id
              return (
                <button
                  key={cat.id}
                  onClick={() => setSelectedCat(cat.id)}
                  className={`filter-pill ${isActive ? 'active' : ''}`}
                >
                  {cat.name}
                </button>
              )
            })}
          </div>
        </div>

        {/* Products Grid */}
        {filteredProducts.length > 0 ? (
          <motion.div className="products-grid" layout>
            <AnimatePresence>
              {filteredProducts.map((p) => (
                <ProductCard
                  key={p.id}
                  p={p}
                  onSelect={(product) => setActiveModalProduct(product)}
                />
              ))}
            </AnimatePresence>
          </motion.div>
        ) : (
          <div style={{ padding: '60px 20px', textAlign: 'center', background: 'var(--bg-card)', borderRadius: '24px', border: '1px solid var(--border-card)' }}>
            <p style={{ fontSize: '1.2rem', fontWeight: 600, marginBottom: '8px' }}>
              Nenhuma peça encontrada com essa busca.
            </p>
            <p style={{ color: 'var(--text-secondary)', marginBottom: '20px' }}>
              Tente outros termos ou limpe o filtro para ver todas as criações.
            </p>
            <button
              onClick={() => {
                setSelectedCat('todos')
                setSearchQuery('')
              }}
              className="btn-outline"
            >
              Ver todas as peças
            </button>
          </div>
        )}

        {/* Details Modal */}
        {activeModalProduct && (
          <ProductModal
            product={activeModalProduct}
            onClose={() => setActiveModalProduct(null)}
          />
        )}
      </div>
    </section>
  )
}
