import React from 'react'
import { motion } from 'framer-motion'
import { Star, Sparkles, Quote } from 'lucide-react'
import { testimonials } from '../data/mock'

export default function Depoimentos() {
  return (
    <section id="depoimentos" className="section-padding" style={{ background: 'var(--bg-secondary)' }}>
      <div className="container" style={{ textAlign: 'center' }}>
        <span className="section-label">
          <Sparkles size={16} />
          Prova de Amor
        </span>
        <h2 className="section-title">O que diz quem já recebeu</h2>
        <p className="section-subtitle">
          A maior alegria do nosso ateliê é ver os olhos brilhando ao abrir a caixinha.
          Confira o carinho compartilhado por nossas clientes.
        </p>

        <div className="testimonials-grid">
          {testimonials.map((t, idx) => (
            <motion.div
              key={t.id}
              className="testimonial-card"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: idx * 0.12 }}
            >
              <div>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '14px' }}>
                  <div className="stars-row" style={{ margin: 0 }}>
                    {[...Array(t.rating)].map((_, i) => (
                      <Star key={i} size={17} fill="currentColor" />
                    ))}
                  </div>
                  <span style={{ fontSize: '0.78rem', color: 'var(--accent)', fontWeight: 700, background: 'var(--accent-light)', padding: '3px 10px', borderRadius: '999px' }}>
                    {t.itemPurchased}
                  </span>
                </div>
                <p className="testimonial-comment">"{t.comment}"</p>
              </div>

              <div className="testimonial-author-box">
                <img src={t.avatar} alt={t.name} className="author-avatar" />
                <div style={{ textAlign: 'left' }}>
                  <div className="author-name">{t.name}</div>
                  <div className="author-info">{t.city} • {t.role}</div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
