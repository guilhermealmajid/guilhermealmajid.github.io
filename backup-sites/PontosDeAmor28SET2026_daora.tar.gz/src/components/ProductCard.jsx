import React from "react";
import { motion } from "framer-motion";
import { Eye, MessageCircle } from "lucide-react";
import { BRAND, buildWhatsAppUrl } from "../data/mock";

export default function ProductCard({ p, onSelect }) {
  const whatsappMsg = `Olá ${BRAND.artisan}! Gostei da peça *${p.name}* (R$ ${p.price.toFixed(2).replace(".", ",")}) e gostaria de encomendar!`;

  return (
    <motion.div
      className="product-card"
      layout
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.35 }}
    >
      {/* Thumbnail */}
      <div
        className="product-thumb-wrap"
        onClick={() => onSelect && onSelect(p)}
        style={{ cursor: "pointer" }}
      >
        <img
          src={p.image}
          alt={p.name}
          className="product-thumb-img"
          loading="lazy"
        />
        {p.badge && <span className="product-badge-tag">{p.badge}</span>}
      </div>

      {/* Content */}
      <div className="product-content-box">
        <span className="product-category-lbl">{p.code}</span>
        <h3 className="product-title">{p.name}</h3>
        <p className="product-desc">{p.description}</p>

        <div className="product-price-row">
          <div>
            <span
              style={{
                fontSize: "0.78rem",
                color: "var(--text-muted)",
                display: "block",
              }}
            >
              A partir de
            </span>
            <span className="product-price-val">
              R$ {p.price.toFixed(2).replace(".", ",")}
            </span>
            <span className="product-price-val" style={{ paddingLeft: "5px" }}>
              {p.obs}
            </span>
          </div>
          <span className="product-prod-time">{p.productionTime}</span>
        </div>

        <div className="product-actions-group">
          <button
            type="button"
            onClick={() => onSelect && onSelect(p)}
            className="btn-card-details"
          >
            <Eye size={16} />
            <span>Detalhes</span>
          </button>

          <a
            href={buildWhatsAppUrl(whatsappMsg)}
            target="_blank"
            rel="noreferrer"
            className="btn-card-order"
          >
            <MessageCircle size={16} />
            <span>Pedir</span>
          </a>
        </div>
      </div>
    </motion.div>
  );
}
