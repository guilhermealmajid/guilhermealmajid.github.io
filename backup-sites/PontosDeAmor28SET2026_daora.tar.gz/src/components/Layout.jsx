import React from 'react'
import Navbar from './Navbar'
import Footer from './Footer'
import WhatsappWidget from './WhatsappWidget'

export default function Layout({ children }) {
  return (
    <div className="app-layout" style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar />
      <main style={{ flexGrow: 1 }}>
        {children}
      </main>
      <WhatsappWidget />
      <Footer />
    </div>
  )
}
