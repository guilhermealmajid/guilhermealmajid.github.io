import React from 'react'
import { motion } from 'framer-motion'
import { HeartHandshake, Sparkles, Palette, Gift, Truck, MessageCircle } from 'lucide-react'
import { differentials } from '../data/mock'

const iconMap = {
  HeartHandshake,
  Sparkles,
  Palette,
  Gift,
  Truck,
  MessageCircle,
}

export default function Diferenciais() {
  return (
    <section id="diferenciais" className="section-padding">
      <div className="container" style={{ textAlign: 'center' }}>
        <span className="section-label">
          <Sparkles size={16} />
          Por que nos escolher
        </span>
        <h2 className="section-title">O cuidado presente em cada detalhe</h2>
        <p className="section-subtitle">
          Mais do que apenas pontos de crochê, entregamos peças cheias de significado,
          conforto e qualidade duradoura para fazer parte da sua história.
        </p>

        <div className="differentials-grid">
          {differentials.map((item, index) => {
            const IconComponent = iconMap[item.icon] || Sparkles
            return (
              <motion.div
                key={index}
                className="differential-card"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: '-50px' }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
              >
                <div className="diff-icon-box">
                  <IconComponent size={26} />
                </div>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </motion.div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
