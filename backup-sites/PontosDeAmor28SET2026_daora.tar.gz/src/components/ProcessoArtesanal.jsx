import React from 'react'
import { motion } from 'framer-motion'
import { Sparkles } from 'lucide-react'
import { steps } from '../data/mock'

export default function ProcessoArtesanal() {
  return (
    <section id="processo" className="section-padding">
      <div className="container" style={{ textAlign: 'center' }}>
        <span className="section-label">
          <Sparkles size={16} />
          Como Funciona
        </span>
        <h2 className="section-title">Do Fio à Sua Casa</h2>
        <p className="section-subtitle">
          Entenda como funciona o caminho artesanal desde o primeiro contato até o
          momento em que você recebe sua encomenda perfumada.
        </p>

        <div className="steps-grid">
          {steps.map((st, index) => (
            <motion.div
              key={st.number}
              className="step-card"
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-50px' }}
              transition={{ duration: 0.5, delay: index * 0.12 }}
            >
              <div className="step-badge-num">{st.number}</div>
              <h3>{st.title}</h3>
              <p>{st.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
