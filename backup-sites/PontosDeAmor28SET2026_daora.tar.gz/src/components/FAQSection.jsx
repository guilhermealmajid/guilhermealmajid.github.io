import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Sparkles, ChevronDown, MessageCircle } from 'lucide-react'
import { faqs, BRAND, buildWhatsAppUrl } from '../data/mock'

export default function FAQSection() {
  const [openIndex, setOpenIndex] = useState(0)

  const toggleItem = (idx) => {
    setOpenIndex(prev => (prev === idx ? null : idx))
  }

  return (
    <section id="faq" className="section-padding">
      <div className="container" style={{ textAlign: 'center' }}>
        <span className="section-label">
          <Sparkles size={16} />
          Dúvidas Frequentes
        </span>
        <h2 className="section-title">Perguntas & Respostas</h2>
        <p className="section-subtitle">
          Tire suas dúvidas sobre prazos, cuidados, materiais e processo de encomenda
          das peças artesanais.
        </p>

        <div className="faq-wrap">
          {faqs.map((faq, index) => {
            const isOpen = openIndex === index
            return (
              <div key={index} className="faq-item">
                <button
                  type="button"
                  onClick={() => toggleItem(index)}
                  className="faq-question-btn"
                  aria-expanded={isOpen}
                >
                  <span>{faq.question}</span>
                  <motion.div
                    animate={{ rotate: isOpen ? 180 : 0 }}
                    transition={{ duration: 0.25 }}
                  >
                    <ChevronDown size={20} style={{ color: 'var(--accent)', flexShrink: 0 }} />
                  </motion.div>
                </button>

                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: 'easeInOut' }}
                      style={{ overflow: 'hidden' }}
                    >
                      <div className="faq-answer-box">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )
          })}
        </div>

        {/* WhatsApp Direct Help Banner */}
        <div style={{
          marginTop: '45px',
          background: 'var(--bg-card)',
          border: '1px solid var(--border-card)',
          borderRadius: '24px',
          padding: '30px 24px',
          display: 'inline-flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: '14px',
          boxShadow: 'var(--shadow-sm)'
        }}>
          <p style={{ fontWeight: 600, fontSize: '1.05rem' }}>
            Ainda tem alguma dúvida ou quer pedir algo diferente?
          </p>
          <a
            href={buildWhatsAppUrl(`Olá ${BRAND.artisan}! Estou com uma dúvida e gostaria da sua ajuda.`)}
            target="_blank"
            rel="noreferrer"
            className="btn-whatsapp"
          >
            <MessageCircle size={18} />
            <span>Tirar dúvidas no WhatsApp</span>
          </a>
        </div>
      </div>
    </section>
  )
}
