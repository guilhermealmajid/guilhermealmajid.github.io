import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MessageCircle, X, Send, Sparkles } from "lucide-react";
import { BRAND, buildWhatsAppUrl } from "../data/mock";

const quickSuggestions = [
  "Quero saber mais sobre as Bolsas Artesanais ✨",
  "Gostaria de encomendar Moda Praia sob medida ☀️",
  "Qual o valor do Jogo de Sousplat Tulipas? 🍽️",
  "Quero solicitar uma peça personalizada 🧶",
];

function InstagramIcon({ size = 26 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="20" height="20" x="2" y="2" rx="5" ry="5" />
      <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
      <line x1="17.5" x2="17.51" y1="6.5" y2="6.5" />
    </svg>
  );
}

export default function WhatsappWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [customText, setCustomText] = useState("");
  const [unreadCount, setUnreadCount] = useState(1);

  const handleToggle = () => {
    setIsOpen(!isOpen);
    if (!isOpen) {
      setUnreadCount(0);
    }
  };

  const handleSend = (textToSend) => {
    const text =
      textToSend ||
      customText ||
      `Olá ${BRAND.artisan}! Vim pelo site Pontos de Amor e gostaria de conversar.`;
    const url = buildWhatsAppUrl(text);
    window.open(url, "_blank", "noopener,noreferrer");
    setIsOpen(false);
  };

  return (
    <div className="whatsapp-floating-container" style={{ marginTop: "30px" }}>
      {/* Interactive Chat Popup Box */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            className="whatsapp-chat-box"
            initial={{ opacity: 0, scale: 0.85, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.85, y: 20 }}
            transition={{ type: "spring", damping: 25, stiffness: 300 }}
          >
            {/* Header */}
            <div className="whatsapp-chat-header">
              <div className="chat-profile-info">
                <div className="chat-avatar-wrap">
                  <img
                    src={BRAND.logo}
                    alt={BRAND.artisan}
                    className="chat-avatar"
                  />
                  <span className="status-online-dot" />
                </div>
                <div className="chat-header-text">
                  <b>
                    {BRAND.name} • {BRAND.artisan}
                  </b>
                  <span>Online agora • Responde rápido</span>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsOpen(false)}
                style={{ color: "#FFF", opacity: 0.85, padding: "4px" }}
                aria-label="Fechar conversa"
              >
                <X size={20} />
              </button>
            </div>

            {/* Body */}
            <div className="whatsapp-chat-body">
              <div className="chat-bubble-received">
                Olá! Tudo bem? Seja bem-vinda(o) ao nosso cantinho artesanal! 🧶
                <br />
                <br />
                Como posso ajudar você hoje a escolher ou criar sua peça
                especial?
              </div>

              {/* Quick suggestions */}
              <div className="quick-prompts-list">
                {quickSuggestions.map((prompt, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleSend(prompt)}
                    className="quick-prompt-btn"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>

            {/* Input area */}
            <div className="chat-input-area">
              <input
                type="text"
                placeholder="Escreva sua mensagem..."
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") handleSend();
                }}
                className="chat-text-input"
              />
              <button
                type="button"
                onClick={() => handleSend()}
                className="chat-send-btn"
                aria-label="Enviar mensagem WhatsApp"
              >
                <Send size={16} />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Instagram Button */}
      <a
        href={
          BRAND.instagramUrl || "https://www.instagram.com/pontosdeamorlayla/"
        }
        target="_blank"
        rel="noreferrer"
        className="instagram-trigger-btn"
        aria-label="Siga-nos no Instagram @pontosdeamorlayla"
        title="Instagram @pontosdeamorlayla"
      >
        <InstagramIcon size={28} />
      </a>

      {/* Floating WhatsApp Trigger Button */}
      <button
        type="button"
        onClick={handleToggle}
        className="whatsapp-trigger-btn"
        aria-label="Falar conosco pelo WhatsApp"
      >
        <span className="whatsapp-pulse-ring" />
        <MessageCircle size={32} />
        {unreadCount > 0 && !isOpen && (
          <span className="whatsapp-unread-badge">{unreadCount}</span>
        )}
      </button>
    </div>
  );
}
