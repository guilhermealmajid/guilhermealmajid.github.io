import React, { useState, useEffect } from 'react'
import { createPortal } from 'react-dom'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Heart, Sun, Moon, MessageCircle, Menu, X, ArrowRight, Sparkles } from 'lucide-react'
import { useTheme } from '../context/ThemeContext'
import { BRAND, buildWhatsAppUrl } from '../data/mock'

export default function Navbar() {
  const { isDark, toggleTheme } = useTheme()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const location = useLocation()
  const navigate = useNavigate()

  const navItems = [
    { label: 'Início', href: '/#hero' },
    { label: 'Diferenciais', href: '/#diferenciais' },
    { label: 'Coleção', href: '/#colecao' },
    { label: 'Simulador', href: '/#personalizado' },
    { label: 'Processo', href: '/#processo' },
    { label: 'Depoimentos', href: '/#depoimentos' },
    { label: 'FAQ', href: '/#faq' },
  ]

  // Fecha menu móvel ao teclar Escape
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') setMobileMenuOpen(false)
    }
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [])

  // Bloqueia rolagem do body quando o menu lateral está aberto
  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = 'hidden'
    } else {
      document.body.style.overflow = ''
    }
    return () => {
      document.body.style.overflow = ''
    }
  }, [mobileMenuOpen])

  const handleNavClick = (href) => {
    setMobileMenuOpen(false)
    if (href.startsWith('/#')) {
      const id = href.replace('/#', '')
      if (location.pathname === '/') {
        setTimeout(() => {
          const el = document.getElementById(id)
          if (el) {
            el.scrollIntoView({ behavior: 'smooth' })
          }
        }, 150)
      } else {
        navigate('/')
        setTimeout(() => {
          const el = document.getElementById(id)
          if (el) {
            el.scrollIntoView({ behavior: 'smooth' })
          }
        }, 250)
      }
    } else {
      navigate(href)
    }
  }

  return (
    <>
      <header className="header-sticky">
        <div className="container nav-container">
          {/* Brand */}
          <Link to="/" className="brand-link" onClick={() => handleNavClick('/#hero')}>
            <img
              src={BRAND.logo}
              alt={BRAND.name}
              style={{
                width: '48px',
                height: '48px',
                borderRadius: '50%',
                objectFit: 'cover',
                border: '2px solid var(--accent)',
                boxShadow: 'var(--shadow-sm)',
                flexShrink: 0
              }}
            />
            <div>
              <span className="brand-text">{BRAND.name}</span>
              <span className="brand-subtext">{BRAND.subname || 'by Layla Almeida'}</span>
            </div>
          </Link>

          {/* Desktop Nav Links */}
          <nav className="nav-links">
            {navItems.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={(e) => {
                  e.preventDefault()
                  handleNavClick(item.href)
                }}
                className="nav-item"
              >
                {item.label}
              </a>
            ))}
          </nav>

          {/* Actions (Theme Switch + WhatsApp CTA + Hamburger Button) */}
          <div className="nav-actions">
            {/* Theme Toggle Button */}
            <button
              type="button"
              onClick={toggleTheme}
              className="theme-toggle-btn"
              aria-label={isDark ? 'Mudar para tema claro' : 'Mudar para tema escuro'}
              title={isDark ? 'Tema Claro' : 'Tema Escuro'}
            >
              <motion.div
                key={isDark ? 'dark' : 'light'}
                initial={{ rotate: -90, opacity: 0, scale: 0.7 }}
                animate={{ rotate: 0, opacity: 1, scale: 1 }}
                exit={{ rotate: 90, opacity: 0, scale: 0.7 }}
                transition={{ duration: 0.25 }}
              >
                {isDark ? <Sun size={20} className="text-amber-400" /> : <Moon size={20} />}
              </motion.div>
            </button>

            {/* WhatsApp CTA (Desktop) */}
            <a
              href={buildWhatsAppUrl(`Olá ${BRAND.artisan}! Vim pelo site e gostaria de conhecer as peças em crochê.`)}
              target="_blank"
              rel="noreferrer"
              className="btn-whatsapp"
            >
              <MessageCircle size={18} />
              <span>WhatsApp</span>
            </a>

            {/* Mobile Hamburger Toggle Button */}
            <button
              type="button"
              onClick={() => setMobileMenuOpen((prev) => !prev)}
              className="mobile-menu-btn"
              aria-label={mobileMenuOpen ? 'Fechar menu' : 'Abrir menu de opções'}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer Menu Rendered via Portal at document.body level */}
      {typeof document !== 'undefined' &&
        createPortal(
          <AnimatePresence>
            {mobileMenuOpen && (
              <>
                {/* Backdrop Overlay */}
                <motion.div
                  className="mobile-drawer-backdrop"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  transition={{ duration: 0.25 }}
                  onClick={() => setMobileMenuOpen(false)}
                />

                {/* Sliding Drawer */}
                <motion.div
                  className="mobile-drawer"
                  initial={{ x: '100%' }}
                  animate={{ x: 0 }}
                  exit={{ x: '100%' }}
                  transition={{ type: 'spring', damping: 26, stiffness: 220 }}
                >
                  {/* Drawer Header */}
                  <div
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'space-between',
                      marginBottom: '24px',
                      paddingBottom: '16px',
                      borderBottom: '1px solid var(--border-subtle)',
                    }}
                  >
                    <div className="brand-link">
                      <img
                        src={BRAND.logo}
                        alt={BRAND.name}
                        style={{
                          width: '42px',
                          height: '42px',
                          borderRadius: '50%',
                          objectFit: 'cover',
                          border: '2px solid var(--accent)',
                          boxShadow: 'var(--shadow-sm)',
                          flexShrink: 0
                        }}
                      />
                      <div>
                        <span className="brand-text" style={{ fontSize: '1.15rem' }}>
                          {BRAND.name}
                        </span>
                        <span className="brand-subtext">{BRAND.subname || 'by Layla Almeida'}</span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setMobileMenuOpen(false)}
                      className="theme-toggle-btn"
                      style={{ width: '40px', height: '40px' }}
                      aria-label="Fechar menu"
                    >
                      <X size={20} />
                    </button>
                  </div>

                  {/* Navigation Links */}
                  <div
                    style={{
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '4px',
                      flexGrow: 1,
                      overflowY: 'auto',
                    }}
                  >
                    {navItems.map((item) => (
                      <a
                        key={item.href}
                        href={item.href}
                        onClick={(e) => {
                          e.preventDefault()
                          handleNavClick(item.href)
                        }}
                        className="mobile-nav-link"
                      >
                        <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                          <Sparkles size={15} style={{ color: 'var(--accent)', opacity: 0.8 }} />
                          <span>{item.label}</span>
                        </div>
                        <ArrowRight size={16} style={{ opacity: 0.6 }} />
                      </a>
                    ))}
                  </div>

                  {/* Drawer Bottom Controls */}
                  <div
                    style={{
                      marginTop: 'auto',
                      paddingTop: '20px',
                      borderTop: '1px solid var(--border-subtle)',
                      display: 'flex',
                      flexDirection: 'column',
                      gap: '14px',
                    }}
                  >
                    {/* Theme Toggle row */}
                    <div
                      style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        padding: '10px 12px',
                        background: 'var(--bg-card-subtle)',
                        borderRadius: 'var(--radius-md)',
                        border: '1px solid var(--border-card)',
                      }}
                    >
                      <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                        {isDark ? <Moon size={18} /> : <Sun size={18} />}
                        <span style={{ fontSize: '0.92rem', fontWeight: 600 }}>
                          {isDark ? 'Tema Escuro Ativo' : 'Tema Claro Ativo'}
                        </span>
                      </div>
                      <button
                        type="button"
                        onClick={toggleTheme}
                        className="theme-toggle-btn"
                        style={{ width: '38px', height: '38px' }}
                        aria-label="Alternar tema"
                      >
                        {isDark ? <Sun size={18} /> : <Moon size={18} />}
                      </button>
                    </div>

                    {/* WhatsApp Action Button */}
                    <a
                      href={buildWhatsAppUrl(
                        `Olá ${BRAND.artisan}! Vim pelo menu do site e gostaria de saber mais sobre as encomendas de crochê.`
                      )}
                      target="_blank"
                      rel="noreferrer"
                      className="btn-whatsapp"
                      style={{ width: '100%', padding: '14px' }}
                    >
                      <MessageCircle size={20} />
                      <span>Falar no WhatsApp</span>
                    </a>

                    <span
                      style={{
                        textAlign: 'center',
                        fontSize: '0.78rem',
                        color: 'var(--text-muted)',
                      }}
                    >
                      Ateliê {BRAND.name} • {BRAND.artisan}
                    </span>
                  </div>
                </motion.div>
              </>
            )}
          </AnimatePresence>,
          document.body
        )}
    </>
  )
}
