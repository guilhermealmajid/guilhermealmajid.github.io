import {
  LOGO_URL,
  getBolsaImg,
  getPraiaImg,
  getSousplatImg,
  bolsasImages,
  modaPraiaImages,
  sousplatImages,
} from "./images";

export const BRAND = {
  name: "Pontos de Amor",
  subname: "by Layla Almeida",
  slogan: "Crochê Artesanal com Alma e Afeto",
  artisan: "Layla Almeida",
  phone: "5534998884407",
  formattedPhone: "(34) 99888-4407",
  instagram: "@pontosdeamorlayla",
  instagramUrl: "https://www.instagram.com/pontosdeamorlayla/",
  location: "Minas Gerais • Enviamos para todo o Brasil",
  workingHours: "Segunda a Sábado, das 09h às 19h",
  whatsappBaseUrl: "https://wa.me/5534998884407",
  logo: LOGO_URL,
};

export const categories = [
  { id: "todos", name: "Todas as Peças", count: 18 },
  { id: "bolsas", name: "Bolsas Artesanais", count: bolsasImages.length || 14 },
  { id: "modapraia", name: "Moda Praia", count: modaPraiaImages.length || 9 },
  {
    id: "sousplat",
    name: "Sousplat & Mesa Posta",
    count: sousplatImages.length || 20,
  },
];

export const products = [
  // ===================== CATEGORIA BOLSAS =====================
  {
    id: "bolsa-1",
    name: "Bolsa Tiracolo Mostarda com Strass & Flor de Pérolas",
    category: "bolsas",
    price: 99.9,
    featured: true,
    badge: "Mais Vendida",
    code: "BOL-001",
    dimensions: "28cm x 22cm com alça tiracolo regulável de 105cm",
    material:
      "Fio de algodão nobre na cor mostarda/ocre, flor com miolo de pérolas, fivela de coração em strass e plaquinha dourada gravada Layla Almeida.",
    productionTime: "Pronta entrega ou 5 a 7 dias úteis",
    description:
      "Bolsa artesanal em ponto concha sofisticado com caimento estruturado e pingente floral. Traz elegância e vivacidade para qualquer look, do casual ao elegante.",
    image: getBolsaImg("11.42.48 (1)"),
  },
  {
    id: "bolsa-2",
    name: "Bolsa Tiracolo Cacau com Tassel & Coração de Cristais",
    category: "bolsas",
    price: 99.9,
    featured: true,
    badge: "Destaque",
    code: "BOL-002",
    dimensions: "27cm x 23cm com alça longa e pingente tassel",
    material:
      "Fio nobre marrom chocolate, pingente artesanal com coração de cristais, tassel volumoso e plaquinha metálica dourada com assinatura da artesã.",
    productionTime: "3 a 5 dias úteis",
    description:
      "A queridinha atemporal em tom terroso profundo. Prática e versátil, perfeita para o dia a dia e encontros especiais, com acabamento manual impecável.",
    image: getBolsaImg("11.42.48.jpeg"),
  },
  {
    id: "bolsa-3",
    name: "Mini Bag Porta-Celular Duo Marsala & Roxa",
    category: "bolsas",
    price: 59.9,
    featured: false,
    badge: "Tendência",
    code: "BOL-003",
    dimensions:
      "19cm x 13cm (tamanho ideal para todos os modelos de smartphone)",
    material:
      "Fio 100% algodão, apliques de borboleta de resina e flor tridimensional, plaqueta metálica dourada.",
    productionTime: "Pronta entrega / Sob encomenda",
    description:
      "Prática, leve e cheia de charme para levar seu celular, documentos e chaves em passeios, viagens e eventos com as mãos livres.",
    image: getBolsaImg("11.42.50 (2)"),
  },
  {
    id: "bolsa-4",
    name: "Mini Bag Porta-Celular Boho Cru com Tassel Multicolor",
    category: "bolsas",
    price: 89.9,
    featured: false,
    badge: "Boho Chic",
    code: "BOL-004",
    dimensions: "19cm x 13cm com alça tiracolo longa",
    material:
      "Fio natural cru/off-white, botão amadeirado, pingente tassel com fios multicoloridos e plaquinha dourada.",
    productionTime: "2 a 4 dias úteis",
    description:
      "Combinação charmosa entre o minimalismo acolhedor do tom cru e a vibração do tassel colorido artesanal. Ideal para presentes criativos.",
    image: getBolsaImg("11.42.50 (4)"),
  },
  {
    id: "bolsa-5",
    name: "Bolsa Jade Esmeralda com Broche Floral de Cristais",
    category: "bolsas",
    price: 179.9,
    featured: true,
    badge: "Coleção Luxo",
    code: "BOL-005",
    dimensions: "26cm x 22cm com forro e alça tiracolo",
    material:
      "Fio especial verde esmeralda com textura encorpada, broche de pedras verdes facetadas e placa gravada em metal dourado.",
    productionTime: "6 a 8 dias úteis",
    description:
      "Uma verdadeira joia tecida ponto a ponto. O contraste do verde vibrante com o broche de cristais cria uma peça exuberante para momentos inesquecíveis.",
    image: getBolsaImg("11.42.49.jpeg"),
  },
  {
    id: "bolsa-6",
    name: "Mini Bag Porta-Celular Lavanda & Ametista",
    category: "bolsas",
    price: 89.9,
    featured: false,
    badge: "Delicada",
    code: "BOL-006",
    dimensions: "19cm x 13cm com alça tiracolo",
    material:
      "Fio de algodão premium tom lavanda/violeta com florzinha rosa e pérola central.",
    productionTime: "3 a 5 dias úteis",
    description:
      "Cores suaves e românticas em um modelo anatômico que protege seu telefone e adiciona feminilidade e aconchego ao seu visual.",
    image: getBolsaImg("11.42.50 (3)"),
  },

  // ===================== CATEGORIA MODA PRAIA =====================
  {
    id: "praia-1",
    name: "Conjunto Beachwear Esmeralda (Biquíni & Saia com Franjas)",
    category: "modapraia",
    price: 169.9,
    featured: true,
    badge: "Coleção Verão",
    code: "PRA-001",
    dimensions: "Tamanhos sob medida (P, M, G ou GG) com cordões reguláveis",
    material:
      "Fio especial para moda praia, resistente à água salgada e sol, com detalhes em borboleta de cristal e miçangas amadeiradas nas franjas.",
    productionTime: "7 a 10 dias úteis",
    description:
      "Conjunto deslumbrante composto por biquíni cortininha bicolor (verde esmeralda e cru) com detalhes de pedraria e saia saída de praia assimétrica com franjas esvoaçantes.",
    image: getPraiaImg("11.47.43 (1)"),
  },
  {
    id: "praia-2",
    name: "Top Cropped Moda Praia Arrastão Dourado & Preto",
    category: "modapraia",
    price: 79.9,
    featured: true,
    badge: "Tendência 2026",
    code: "PRA-002",
    dimensions: "Modelagem cropped com amarração ajustável no pescoço e costas",
    material:
      "Fio mesclado dourado e preto de toque macio e caimento fluido com ponto arrastão aberto.",
    productionTime: "5 a 8 dias úteis",
    description:
      "Top cropped artesanal com busto trabalhado e trama aberta em ponto arrastão. Perfeito para festas na praia, sunsets, cruzeiros e passeios de verão.",
    image: getPraiaImg("11.47.42.jpeg"),
  },
  {
    id: "praia-3",
    name: "Conjunto Biquíni & Saída de Praia Nude Terracota com Franjas",
    category: "modapraia",
    price: 169.9,
    featured: true,
    badge: "Mais Desejado",
    code: "PRA-003",
    dimensions: "Confeccionado sob encomenda nas medidas exatas da cliente",
    material:
      "Fio 100% nobre na cor nude areia/terracota com contas amadeiradas nas pontas das franjas.",
    productionTime: "7 a 12 dias úteis",
    description:
      "O clássico tom terroso que valoriza todos os tons de pele. A saia com franjas longas proporciona movimento fluido e sofisticado ao caminhar à beira-mar.",
    image: getPraiaImg("11.45.15.jpeg"),
  },
  {
    id: "praia-4",
    name: "Saída de Praia Assimétrica com Franjas Artesanais",
    category: "modapraia",
    price: 139.9,
    featured: false,
    badge: "Resort Wear",
    code: "PRA-004",
    dimensions: "Comprimento regulável com amarração lateral",
    material: "Trama aberta leve e respirável em fio de algodão nobre.",
    productionTime: "5 a 7 dias úteis",
    description:
      "Peça indispensável na mala de viagem. Veste perfeitamente por cima do biquíni com ajuste fácil na cintura e caimento drapeado impecável.",
    image: getPraiaImg("11.45.15 (1)"),
  },
  {
    id: "praia-5",
    name: "Biquíni Cortininha Crochê com Borboleta de Cristal",
    category: "modapraia",
    price: 119.9,
    featured: false,
    badge: "Exclusivo",
    code: "PRA-005",
    dimensions: "Bojo sob consulta (P, M, G) com amarração nas costas",
    material:
      "Fio macio que mantém a estrutura na água com forro interno e pedraria de borboleta.",
    productionTime: "4 a 6 dias úteis",
    description:
      "Biquíni artesanal com bico rendado nas laterais e broche central de borboleta translúcida em tom esmeralda. Elegância solar.",
    image: getPraiaImg("11.47.42 (1)"),
  },
  {
    id: "praia-6",
    name: "Saia de Praia com Franjas & Miçangas Green Paradise",
    category: "modapraia",
    price: 139.9,
    featured: false,
    badge: "Verde Tropical",
    code: "PRA-006",
    dimensions: "Cintura ajustável por cordão com tassel e miçangas",
    material:
      "Fio de crochê verde esmeralda encorpado com caimento pesado nas franjas.",
    productionTime: "5 a 7 dias úteis",
    description:
      "A saia perfeita para curtir passeios de barco e beach clubs com glamour e originalidade artesanal que você não encontra em lojas comuns.",
    image: getPraiaImg("11.47.43 (2)"),
  },

  // ===================== CATEGORIA SOUSPLAT =====================
  {
    id: "sousplat-1",
    name: "Sousplat Tulipas Jardim de Primavera (Mesa Posta)",
    category: "sousplat",
    price: 44.9,
    featured: true,
    badge: "Mais Vendido",
    code: "SOU-001",
    dimensions: "38cm de diâmetro (tamanho padrão para pratos rasos e bowls)",
    material:
      "Fio 100% algodão mercerizado branco neve, tulipas em relevo rosa e sépalas verde oliva, placa metálica gravada em dourado.",
    productionTime: "4 a 8 dias úteis (jogos)",
    description:
      "Nosso clássico mais amado! Borda esculpida com pequenas tulipas em relevo 3D que parecem brotar ao redor do prato. Transforma qualquer café ou jantar em momento especial.",
    image: getSousplatImg("11.41.18.jpeg"),
  },
  {
    id: "sousplat-2",
    name: "Jogo Sousplat & Porta-Copos Imperial Roxo com Pérolas",
    category: "sousplat",
    price: 169.9,
    featured: true,
    badge: "Jogo Completo",
    code: "SOU-002",
    dimensions: "1 Sousplat grande (40cm) + 4 Porta-copos (15cm cada)",
    material:
      "Fio de alta gramatura na cor roxo imperial com arabescos brancos, mini flores coloridas bordadas com pérolas e plaquinhas de metal dourado.",
    productionTime: "6 a 9 dias úteis",
    description:
      "Sofisticação e nobreza em tons de roxo profundo. O kit com descansos de copos coordenados cria uma experiência memorável e requintada para seus convidados.",
    image: getSousplatImg("11.41.21.jpeg"),
  },
  {
    id: "sousplat-3",
    name: "Jogo Sousplat Edição Festiva Cenourinhas & Ramos",
    category: "sousplat",
    price: 89.9,
    featured: false,
    badge: "Edição Especial",
    code: "SOU-003",
    dimensions: "Par com 2 sousplats de 37cm de diâmetro cada",
    material:
      "Fio branco puro com bordado contínuo de cenourinhas laranjas e folhagens verdes, com detalhe de cruz / ramos festivos e plaquinha dourada.",
    productionTime: "4 a 6 dias úteis",
    description:
      "Ideal para almoços de Páscoa, reuniões em família e café da manhã acolhedor com temática alegre e acabamento artesanal impecável.",
    image: getSousplatImg("11.41.16.jpeg"),
  },
  {
    id: "sousplat-4",
    name: "Sousplat Romântico Margaridas & Tulipas com Borda Rendada",
    category: "sousplat",
    price: 42.9,
    obs: "(1 peças)",
    featured: false,
    badge: "Delicadeza",
    code: "SOU-004",
    dimensions: "38cm de diâmetro",
    material:
      "Fio de algodão com acabamento natural para caimento firme e prático na mesa.",
    productionTime: "3 a 6 dias úteis",
    description:
      "Composição suave que harmoniza perfeitamente com louças brancas, florais ou de cerâmica, trazendo o calor do feito à mão para suas refeições.",
    image: getSousplatImg("11.41.17.jpeg"),
  },
  {
    id: "sousplat-5",
    name: "Jogo Sousplat Elegance Mesa Posta Off-White",
    category: "sousplat",
    price: 149.9,
    obs: "(4 peças)",
    observation: "4 peças",
    featured: true,
    badge: "Jogo 4 Peças",
    code: "SOU-005",
    dimensions: "Jogo com 4 sousplats de 38cm cada",
    material:
      "Fio nobre cru/off-white com pontos relevo e caimento plano perfeito.",
    productionTime: "5 a 8 dias úteis",
    description:
      "Atemporal e indispensável. Uma base neutra e elegante que combina com qualquer guardanapo de tecido e anel porta-guardanapo.",
    image: getSousplatImg("11.41.19.jpeg"),
  },
  {
    id: "sousplat-6",
    name: "Sousplat Floral Romântico com Placa Dourada Exclusiva",
    category: "sousplat",
    price: 44.9,
    featured: false,
    badge: "Assinatura Layla",
    code: "SOU-006",
    dimensions: "38cm de diâmetro",
    material:
      "Fio 100% algodão de espessura nobre com plaquinha dourada gravada a laser com a marca do ateliê.",
    productionTime: "3 a 5 dias úteis",
    description:
      "Cada peça carrega a assinatura em metal dourado da artesã Layla Almeida, comprovando a autenticidade e o cuidado artesanal do início ao fim.",
    image: getSousplatImg("11.41.20.jpeg"),
  },
];

export const differentials = [
  {
    icon: "HeartHandshake",
    title: "100% Ponto a Ponto",
    description:
      "Cada laçada é tecida exclusivamente pela artesã Layla Almeida, respeitando o tempo e a magia do trabalho manual.",
  },
  {
    icon: "Sparkles",
    title: "Fios Nobres & Detalhes de Luxo",
    description:
      "Algodão de alta qualidade, pedrarias, fivelas de strass, broches e plaquinhas de metal dourado com a marca gravada.",
  },
  {
    icon: "Palette",
    title: "Cores e Tamanhos Personalizados",
    description:
      "Encomende no seu tamanho exato (moda praia sob medida) ou na paleta de cores perfeita para a sua decoração.",
  },
  {
    icon: "Gift",
    title: "Embalagem Perfumada & Afeto",
    description:
      "Sua encomenda chega com aroma exclusivo de ateliê, embalagem delicada para presente e cartão com dicas de cuidados.",
  },
  {
    icon: "Truck",
    title: "Envio Seguro para Todo Brasil",
    description:
      "Embalagens seguras com código de rastreamento e suporte em cada etapa até a entrega na sua porta.",
  },
  {
    icon: "MessageCircle",
    title: "Atendimento Direto com a Layla",
    description:
      "Tire dúvidas, escolha cores e acompanhe o andamento da sua encomenda diretamente pelo WhatsApp.",
  },
];

export const steps = [
  {
    number: "01",
    title: "Escolha ou Encomende",
    description:
      "Navegue pelo nosso catálogo de Bolsas, Moda Praia e Sousplats ou traga sua inspiração sob medida.",
  },
  {
    number: "02",
    title: "Definição de Medidas e Cores",
    description:
      "A Layla alinha cada detalhe com você no WhatsApp: medidas do corpo, paleta de tons e acabamentos especiais.",
  },
  {
    number: "03",
    title: "Confecção Artesanal com Amor",
    description:
      "Sua peça ganha forma ponto a ponto com fios nobres e aplicação da plaquinha dourada Pontos de Amor.",
  },
  {
    number: "04",
    title: "Embalagem Perfumada & Entrega",
    description:
      "Receba em casa uma caixinha acolhedora, com cheirinho especial de ateliê e pronta para encantar.",
  },
];

export const testimonials = [
  {
    id: 1,
    name: "Carolina Mendes",
    city: "Belo Horizonte - MG",
    role: "Cliente Encantada",
    rating: 5,
    avatar:
      "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80",
    comment:
      "A bolsa tiracolo mostarda é simplesmente uma obra de arte! O ponto é muito firme, o coração de strass dá um brilho incrível e a plaquinha dourada deixa super sofisticada. Virei fã!",
    itemPurchased: "Bolsa Tiracolo Mostarda",
  },
  {
    id: 2,
    name: "Mariana Duarte",
    city: "São Paulo - SP",
    role: "Amante de Mesa Posta",
    rating: 5,
    avatar:
      "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=150&q=80",
    comment:
      "Comprei o jogo de sousplats com as tulipas rosas. Gente, que coisa mais linda! As tulipas em relevo parecem de verdade, meus convidados ficaram apaixonados. O cheirinho da caixa é maravilhoso.",
    itemPurchased: "Sousplat Tulipas Jardim",
  },
  {
    id: 3,
    name: "Fernanda Rocha",
    city: "Uberlândia - MG",
    role: "Cliente Frequente",
    rating: 5,
    avatar:
      "https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=150&q=80",
    comment:
      "O conjunto de moda praia verde com a saia de franjas vestiu como uma luva nas minhas medidas! A Layla foi super atenciosa no WhatsApp durante todo o processo de encomenda.",
    itemPurchased: "Conjunto Beachwear Esmeralda",
  },
];

export const faqs = [
  {
    question: "Qual é o prazo médio de confecção das peças sob encomenda?",
    answer:
      'O prazo varia entre 4 a 10 dias úteis, dependendo da peça (bolsas, moda praia sob medida ou jogos de sousplat). Peças com etiqueta de "Pronta Entrega" são postadas em até 24 horas úteis!',
  },
  {
    question:
      "Como escolher o tamanho correto para os conjuntos de Moda Praia?",
    answer:
      "Ao nos chamar no WhatsApp, a Layla solicita as suas medidas de busto, cintura e quadril para confeccionar o biquíni e a saia perfeitamente ajustados ao seu corpo, garantindo conforto e caimento sob medida.",
  },
  {
    question: "As bolsas e sousplats vêm com a plaquinha dourada da marca?",
    answer:
      'Sim! Nossas peças contam com a charmosa plaquinha metálica dourada com a assinatura "Layla Almeida", que garante autenticidade e valoriza o artesanato exclusivo de luxo.',
  },
  {
    question: "Como lavar e cuidar das minhas peças de crochê?",
    answer:
      "Recomendamos lavagem manual suave com água fria e sabão neutro. Não torça (apenas pressione delicadamente para retirar o excesso de água) e seque sempre na horizontal e à sombra para preservar a forma dos pontos.",
  },
  {
    question: "Quais formas de pagamento o ateliê aceita?",
    answer:
      "Aceitamos Pix (com confirmação imediata), transferência bancária e cartão de crédito em até 3x sem juros (ou até 12x via link seguro).",
  },
  {
    question: "Vocês enviam para todo o Brasil?",
    answer:
      "Sim! Enviamos para todos os estados através dos Correios (PAC / Sedex) ou transportadoras parceiras, com código de rastreamento enviado diretamente no seu WhatsApp.",
  },
];

export function buildWhatsAppUrl(message) {
  return `${BRAND.whatsappBaseUrl}?text=${encodeURIComponent(message)}`;
}
