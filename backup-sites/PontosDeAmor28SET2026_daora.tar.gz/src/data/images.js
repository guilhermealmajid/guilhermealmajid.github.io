import logoImg from '../images/logo.jpeg'

// Importa todas as imagens das 3 categorias usando Vite glob
const bolsaGlob = import.meta.glob('../images/Categorias/Bolsas/*.{jpeg,jpg,png}', { eager: true, import: 'default' })
const praiaGlob = import.meta.glob('../images/Categorias/ModaPraia/*.{jpeg,jpg,png}', { eager: true, import: 'default' })
const sousplatGlob = import.meta.glob('../images/Categorias/Sousplat/*.{jpeg,jpg,png}', { eager: true, import: 'default' })

export const LOGO_URL = logoImg

export const bolsasImages = Object.entries(bolsaGlob).map(([path, url]) => ({
  path,
  url,
  filename: path.split('/').pop()
}))

export const modaPraiaImages = Object.entries(praiaGlob).map(([path, url]) => ({
  path,
  url,
  filename: path.split('/').pop()
}))

export const sousplatImages = Object.entries(sousplatGlob).map(([path, url]) => ({
  path,
  url,
  filename: path.split('/').pop()
}))

export function getBolsaImg(pattern) {
  const found = bolsasImages.find(img => img.filename.includes(pattern))
  return found ? found.url : (bolsasImages[0]?.url || logoImg)
}

export function getPraiaImg(pattern) {
  const found = modaPraiaImages.find(img => img.filename.includes(pattern))
  return found ? found.url : (modaPraiaImages[0]?.url || logoImg)
}

export function getSousplatImg(pattern) {
  const found = sousplatImages.find(img => img.filename.includes(pattern))
  return found ? found.url : (sousplatImages[0]?.url || logoImg)
}
