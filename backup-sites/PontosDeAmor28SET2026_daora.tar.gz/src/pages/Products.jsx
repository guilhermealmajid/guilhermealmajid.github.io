import React, { useState } from 'react'
import { useSearchParams, Link } from 'react-router-dom'
import { Sparkles, ArrowLeft } from 'lucide-react'
import { categories, products } from '../data/mock'
import ProductCard from '../components/ProductCard'
import ProductModal from '../components/ProductModal'

export default function Products() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [activeModalProduct, setActiveModalProduct] = useState(null)
  const currentCategory = searchParams.get('categoria') || 'todos'

  const filteredList =
    currentCategory === 'todos'
      ? products
      : products.filter((p) => p.category === currentCategory)

  return (
    <div className="section-padding">
      <div className="container">
        <div style={{ marginBottom: '24px' }}>
          <Link to="/" className="btn-outline" style={{ display: 'inline-flex', padding: '8px 16px', fontSize: '0.88rem' }}>
            <ArrowLeft size={16} />
            <span>Voltar para Início</span>
          </Link>
        </div>

        <div style={{ textAlign: 'center', marginBottom: '40px' }}>
          <span className="section-label">
            <Sparkles size={16} />
            Catálogo Completo
          </span>
          <h1 className="section-title">Todos os Trabalhos em Crochê</h1>
          <p className="section-subtitle">
            Explore nossa galeria de criações artesanais feitas com carinho e dedicação ponto a ponto.
          </p>

          <div className="filter-pills-row" style={{ marginTop: '28px' }}>
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() =>
                  c.id === 'todos' ? setSearchParams({}) : setSearchParams({ categoria: c.id })
                }
                className={`filter-pill ${currentCategory === c.id ? 'active' : ''}`}
              >
                {c.name}
              </button>
            ))}
          </div>
        </div>

        <div className="products-grid">
          {filteredList.map((p) => (
            <ProductCard
              key={p.id}
              p={p}
              onSelect={(item) => setActiveModalProduct(item)}
            />
          ))}
        </div>

        {activeModalProduct && (
          <ProductModal
            product={activeModalProduct}
            onClose={() => setActiveModalProduct(null)}
          />
        )}
      </div>
    </div>
  )
}