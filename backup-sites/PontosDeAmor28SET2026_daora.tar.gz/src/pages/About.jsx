import React from 'react'
import { Link } from 'react-router-dom'
import { Sparkles, Heart, ArrowLeft, MessageCircle } from 'lucide-react'
import { BRAND, buildWhatsAppUrl } from '../data/mock'

export default function About() {
  return (
    <main className="container section-padding">
      <div style={{ marginBottom: '28px' }}>
        <Link to="/" className="btn-outline" style={{ display: 'inline-flex', padding: '8px 16px', fontSize: '0.88rem' }}>
          <ArrowLeft size={16} />
          <span>Voltar para Início</span>
        </Link>
      </div>

      <div style={{
        maxWidth: '860px',
        margin: '0 auto',
        background: 'var(--bg-card)',
        border: '1px solid var(--border-card)',
        borderRadius: '32px',
        padding: '50px 40px',
        boxShadow: 'var(--shadow-md)'
      }}>
        <div style={{ textAlign: 'center', marginBottom: '36px' }}>
          <img
            src={BRAND.logo}
            alt={BRAND.name}
            style={{
              width: '90px',
              height: '90px',
              borderRadius: '50%',
              objectFit: 'cover',
              border: '3px solid var(--accent)',
              boxShadow: 'var(--shadow-md)',
              margin: '0 auto 18px',
              display: 'block'
            }}
          />
          <span className="section-label">
            <Heart size={16} fill="currentColor" />
            Nossa História
          </span>
          <h1 className="section-title">Feito Ponto a Ponto com Amor</h1>
          <p className="section-subtitle">
            Conheça o propósito e a dedicação por trás de cada criação do ateliê {BRAND.name} {BRAND.subname}.
          </p>
        </div>

        <div style={{ fontSize: '1.08rem', lineHeight: '1.85', color: 'var(--text-secondary)', display: 'flex', flexDirection: 'column', gap: '22px' }}>
          <p>
            O <strong>{BRAND.name}</strong> nasceu da paixão genuína por transformar fios, texturas e
            cores em peças que abraçam e contam histórias. Sob as mãos da artesã {BRAND.artisan}, o crochê
            deixa de ser apenas uma técnica manual para se tornar uma manifestação de arte, desaceleração e afeto.
          </p>

          <p>
            Em um mundo acelerado e industrial, defendemos a beleza do ritmo artesanal: o tempo
            necessário para escolher os fios mais nobres de algodão, a atenção aos detalhes em cada laçada
            e o compromisso de criar peças duradouras que passam de geração em geração.
          </p>

          <p>
            Seja uma bolsa exclusiva com broches e coração de strass, um conjunto de moda praia feito
            sob medida para os seus dias de sol ou sousplats florais que transformam a sua mesa posta, cada
            peça sai do ateliê perfumada, com plaquinha dourada gravada e embalada com todo carinho.
          </p>
        </div>

        <div style={{
          marginTop: '45px',
          paddingTop: '35px',
          borderTop: '1px solid var(--border-subtle)',
          display: 'flex',
          flexWrap: 'wrap',
          alignItems: 'center',
          justifyContent: 'space-between',
          gap: '20px'
        }}>
          <div>
            <b style={{ fontSize: '1.1rem', display: 'block', color: 'var(--text-primary)' }}>Quer uma peça exclusiva?</b>
            <span style={{ fontSize: '0.9rem', color: 'var(--text-muted)' }}>Conversamos diretamente pelo WhatsApp sobre cores e prazos.</span>
          </div>

          <a
            href={buildWhatsAppUrl(`Olá ${BRAND.artisan}! Li sobre a história do ateliê no site e gostaria de conversar.`)}
            target="_blank"
            rel="noreferrer"
            className="btn-whatsapp"
          >
            <MessageCircle size={18} />
            <span>Falar com a Layla</span>
          </a>
        </div>
      </div>
    </main>
  )
}