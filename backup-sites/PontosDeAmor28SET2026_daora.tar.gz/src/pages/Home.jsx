import React from 'react'
import Hero from '../components/Hero'
import Diferenciais from '../components/Diferenciais'
import CatalogoSection from '../components/CatalogoSection'
import CustomOrderSimulator from '../components/CustomOrderSimulator'
import ProcessoArtesanal from '../components/ProcessoArtesanal'
import Depoimentos from '../components/Depoimentos'
import FAQSection from '../components/FAQSection'

export default function Home() {
  return (
    <>
      <Hero />
      <Diferenciais />
      <CatalogoSection />
      <CustomOrderSimulator />
      <ProcessoArtesanal />
      <Depoimentos />
      <FAQSection />
    </>
  )
}