import React from 'react'
import { useParams, Link } from 'react-router-dom'
import { ArrowLeft, MessageCircle, Ruler, Sparkles, Clock, ShieldCheck } from 'lucide-react'
import { products, BRAND, buildWhatsAppUrl } from '../data/mock'

export default function Product() {
  const { id } = useParams()
  const p = products.find((x) => x.id === id)

  if (!p) {
    return (
      <main className="container section-padding" style={{ textAlign: 'center' }}>
        <h1 className="section-title">Peça não encontrada</h1>
        <p className="section-subtitle" style={{ marginBottom: '24px' }}>
          O item que você está procurando não existe ou já foi descontinuado.
        </p>
        <Link to="/produtos" className="btn-primary">
          Ver Catálogo Completo
        </Link>
      </main>
    )
  }

  const whatsappMsg = `Olá ${BRAND.artisan}! Gostei muito da peça *${p.name}* (${p.code} - R$ ${p.price.toFixed(2).replace('.', ',')}) no site. Gostaria de saber como encomendar!`

  return (
    <main className="container section-padding">
      <div style={{ marginBottom: '28px' }}>
        <Link to="/#colecao" className="btn-outline" style={{ display: 'inline-flex', padding: '8px 16px', fontSize: '0.88rem' }}>
          <ArrowLeft size={16} />
          <span>Voltar para Coleção</span>
        </Link>
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
        gap: '45px',
        alignItems: 'start',
        background: 'var(--bg-card)',
        border: '1px solid var(--border-card)',
        borderRadius: '32px',
        padding: '36px',
        boxShadow: 'var(--shadow-lg)'
      }}>
        <div style={{ borderRadius: '24px', overflow: 'hidden', position: 'relative' }}>
          <img
            src={p.image}
            alt={p.name}
            style={{ width: '100%', maxHeight: '520px', objectFit: 'cover' }}
          />
          {p.badge && (
            <span className="product-badge-tag" style={{ position: 'absolute', top: 16, left: 16 }}>
              {p.badge}
            </span>
          )}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column' }}>
          <span className="product-category-lbl">{p.code}</span>
          <h1 className="section-title" style={{ fontSize: '2.4rem', marginBottom: '14px' }}>
            {p.name}
          </h1>

          <p className="product-desc" style={{ fontSize: '1.05rem', lineHeight: '1.7', marginBottom: '20px', WebkitLineClamp: 'unset' }}>
            {p.description}
          </p>

          <div className="modal-meta-list" style={{ margin: '14px 0 24px' }}>
            <div className="modal-meta-item">
              <Ruler size={18} style={{ color: 'var(--accent)', flexShrink: 0 }} />
              <span><b>Dimensões:</b> {p.dimensions || 'Sob consulta'}</span>
            </div>
            <div className="modal-meta-item">
              <Sparkles size={18} style={{ color: 'var(--accent)', flexShrink: 0 }} />
              <span><b>Material:</b> {p.material || 'Fio 100% Algodão Mercerizado'}</span>
            </div>
            <div className="modal-meta-item">
              <Clock size={18} style={{ color: 'var(--accent)', flexShrink: 0 }} />
              <span><b>Produção:</b> {p.productionTime || 'Pronta Entrega / Sob Encomenda'}</span>
            </div>
            <div className="modal-meta-item">
              <ShieldCheck size={18} style={{ color: 'var(--accent)', flexShrink: 0 }} />
              <span><b>Cuidados:</b> Lavar à mão com sabão neutro e secar na horizontal</span>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'baseline', gap: '10px', marginBottom: '28px' }}>
            <span style={{ fontSize: '1rem', color: 'var(--text-muted)' }}>Investimento:</span>
            <span className="product-price-val" style={{ fontSize: '2.4rem' }}>
              R$ {p.price.toFixed(2).replace('.', ',')}
            </span>
          </div>

          <a
            href={buildWhatsAppUrl(whatsappMsg)}
            target="_blank"
            rel="noreferrer"
            className="btn-whatsapp"
            style={{ width: '100%', padding: '16px', fontSize: '1.05rem' }}
          >
            <MessageCircle size={22} />
            <span>Fazer Pedido no WhatsApp</span>
          </a>
        </div>
      </div>
    </main>
  )
}