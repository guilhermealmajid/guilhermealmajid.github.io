import laylaImg from "/assets/layla-perfil-DYwHufFl.png";

export default function Layla() {
  return (
    <section id="layla" className="py-24 relative overflow-hidden">
      {/* Background accent */}
      <div className="absolute right-0 bottom-0 w-72 h-72 bg-purple-500/5 rounded-full blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="flex items-center gap-4 mb-16">
          <span
            className="text-sm font-mono"
            style={{ color: "var(--neon)", opacity: 0.5 }}
          >
            04.
          </span>
          <h2
            className="text-3xl md:text-4xl font-bold"
            style={{ color: "var(--text-primary)" }}
          >
            <span className="gradient-text-warm">Coordenação</span>
          </h2>
          <div className="flex-1 h-px bg-gradient-to-r from-purple-400/20 to-transparent" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-6 order-2 md:order-1">
            <div className="space-y-2">
              <h3
                className="text-2xl md:text-3xl font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                Layla Almeida
              </h3>
              <div className="flex items-center gap-2">
                <span className="text-xs text-purple-400 bg-purple-400/10 border border-purple-400/20 px-3 py-1 rounded-full">
                  Coordenadora de Projetos
                </span>
                <span
                  className="text-xs"
                  style={{ color: "var(--text-subtle)" }}
                >
                  LGA FORTECH
                </span>
              </div>
            </div>

            <div className="space-y-4">
              <p
                className="leading-relaxed text-sm md:text-base"
                style={{ color: "var(--text-muted)" }}
              >
                Olá, sou Layla Almeida, Coordenadora de Projetos, lado a lado
                com o Guilherme. Atuo para garantir que os projetos dos nossos
                clientes tenham um bom andamento, dando{" "}
                <span
                  className="font-medium"
                  style={{ color: "var(--text-primary)" }}
                >
                  suporte criativo e inovador
                </span>
                , direcionando para a melhor finalização e entrega.
              </p>
              <p
                className="leading-relaxed text-sm md:text-base"
                style={{ color: "var(--text-muted)" }}
              >
                Formação Acadêmica em{" "}
                <span className="text-purple-400 font-medium">
                  Gestão em Recursos Humanos
                </span>
                , mais de 10 anos de experiência em apoio administrativo de
                várias empresas.
              </p>
            </div>

            {/* Attributes */}
            {/* <div className="grid grid-cols-2 gap-4"> */}
            {/*   {[ */}
            {/*     { label: 'Criatividade', value: '98%', color: 'text-purple-400' }, */}
            {/*     { label: 'Organização', value: '95%', color: 'text-cyan-400' }, */}
            {/*     { label: 'Comunicação', value: '97%', color: 'text-purple-400' }, */}
            {/*     { label: 'Liderança', value: '92%', color: 'text-cyan-400' }, */}
            {/*   ].map(attr => ( */}
            {/*     <div key={attr.label} className="glass border-neon rounded-xl p-4 hover:border-purple-400/30 transition-colors duration-300"> */}
            {/*       <div className={`text-xl font-bold ${attr.color}`}>{attr.value}</div> */}
            {/*       <div className="text-xs mt-0.5" style={{ color: 'var(--text-subtle)' }}>{attr.label}</div> */}
            {/*     </div> */}
            {/*   ))} */}
            {/* </div> */}
            {/**/}
            {/* Quote */}
            <div className="glass border-neon rounded-xl p-5 relative overflow-hidden">
              <div className="absolute top-3 right-4 text-6xl text-purple-400/10 font-serif leading-none select-none">
                "
              </div>
              <p
                className="text-sm italic leading-relaxed relative"
                style={{ color: "var(--text-muted)" }}
              >
                Garantimos que cada projeto chegue ao cliente com a qualidade,
                criatividade e inovação que ele merece. Nosso compromisso é com
                a sua satisfação e o crescimento do seu negócio.
              </p>
              <div className="mt-3 text-xs text-purple-400 font-semibold">
                — Layla Almeida
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="flex justify-center md:justify-end order-1 md:order-2">
            <div className="relative">
              {/* Purple glow */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-purple-500/20 to-pink-500/10 blur-xl scale-110" />
              <div className="absolute -inset-1 rounded-2xl border border-purple-400/20" />

              <div className="relative w-64 h-72 md:w-72 md:h-80 rounded-2xl overflow-hidden border-neon">
                <img
                  src={laylaImg}
                  alt="Layla Almeida"
                  className="w-full h-full object-cover object-top"
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background:
                      "linear-gradient(to top, var(--bg) 0%, transparent 60%)",
                  }}
                />
              </div>

              {/* Badge */}
              <div className="absolute -bottom-4 -left-4 glass border-neon rounded-xl px-4 py-2">
                <div
                  className="text-xs"
                  style={{ color: "var(--text-subtle)" }}
                >
                  Gestão
                </div>
                <div className="text-sm font-bold text-purple-400">
                  +10 Anos
                </div>
              </div>

              {/* Floating detail */}
              <div className="absolute -top-4 -right-4 glass border-neon rounded-xl px-3 py-2 float-anim">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 bg-purple-400 rounded-full pulse-ring" />
                  <span className="text-xs text-purple-400 font-semibold">
                    Online
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
