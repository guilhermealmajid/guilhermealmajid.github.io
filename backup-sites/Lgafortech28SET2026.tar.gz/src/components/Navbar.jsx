import { useState, useEffect } from "react";
import { useTheme } from "../context/ThemeContext";

const navLinks = [
  { href: "#home", label: "Início" },
  { href: "#about", label: "Sobre" },
  { href: "#layla", label: "Coordenação" },
  { href: "#work", label: "Portifólio" },
  { href: "https://lgafortech.com.br/pontosdeamor/", label: "Pontos de Amor", target: "_blank" },
  { href: "#experience", label: "Experiência" },
  { href: "#contact", label: "Contato" },
];

/* ── Sun icon ─────────────────────────────────────────────── */
function SunIcon() {
  return (
    <svg
      className="w-3.5 h-3.5"
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
    >
      <circle cx="12" cy="12" r="4" strokeWidth={2} />
      <path
        strokeLinecap="round"
        strokeWidth={2}
        d="M12 2v2M12 20v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M2 12h2M20 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"
      />
    </svg>
  );
}

/* ── Moon icon ────────────────────────────────────────────── */
function MoonIcon() {
  return (
    <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
      <path d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z" />
    </svg>
  );
}

/* ── Theme Toggle ─────────────────────────────────────────── */
function ThemeToggle() {
  const { isDark, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      type="button"
      role="switch"
      aria-checked={!isDark}
      aria-label={isDark ? "Alternar para tema claro" : "Alternar para tema escuro"}
      title={isDark ? "Tema Escuro (Clique para alternar para Claro)" : "Tema Claro (Clique para alternar para Escuro)"}
      className="relative flex items-center justify-between w-14 h-7 p-1 rounded-full border transition-all duration-300 cursor-pointer select-none focus:outline-none focus:ring-2 focus:ring-[var(--neon)]"
      style={{
        borderColor: "var(--border-hover)",
        background: "var(--bg-card)",
      }}
    >
      {/* Thumb slider */}
      <span
        className="absolute top-1 left-1 w-5 h-5 rounded-full transition-transform duration-300 ease-out flex items-center justify-center z-0"
        style={{
          background: "var(--neon)",
          boxShadow: "0 0 10px var(--neon)",
          transform: isDark ? "translateX(0px)" : "translateX(28px)",
        }}
      />

      {/* Moon Icon (Dark Mode - Left) */}
      <span
        className="relative z-10 flex items-center justify-center w-5 h-5 transition-colors duration-300"
        style={{
          color: isDark ? "var(--bg)" : "var(--text-subtle)",
        }}
      >
        <MoonIcon />
      </span>

      {/* Sun Icon (Light Mode - Right) */}
      <span
        className="relative z-10 flex items-center justify-center w-5 h-5 transition-colors duration-300"
        style={{
          color: !isDark ? "#ffffff" : "var(--text-subtle)",
        }}
      >
        <SunIcon />
      </span>
    </button>
  );
}

/* ── Navbar ───────────────────────────────────────────────── */
export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState("home");
  const { isDark } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 40);
      const sections = [
        "home",
        "about",
        "work",
        "experience",
        "layla",
        "contact",
      ];
      for (let i = sections.length - 1; i >= 0; i--) {
        const el = document.getElementById(sections[i]);
        if (el && window.scrollY >= el.offsetTop - 120) {
          setActiveSection(sections[i]);
          break;
        }
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navBg = scrolled
    ? isDark
      ? "rgba(2,4,8,0.85)"
      : "rgba(240,244,255,0.9)"
    : "transparent";

  const navBorder = scrolled
    ? isDark
      ? "1px solid rgba(0,240,255,0.08)"
      : "1px solid rgba(14,165,233,0.1)"
    : "1px solid transparent";

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-500"
      style={{
        background: navBg,
        backdropFilter: scrolled ? "blur(20px)" : "none",
        WebkitBackdropFilter: scrolled ? "blur(20px)" : "none",
        borderBottom: navBorder,
        boxShadow: scrolled ? "0 4px 30px rgba(0,0,0,0.2)" : "none",
      }}
    >
      <nav className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between gap-6">
        {/* Logo */}
        <a href="#home" className="flex items-center gap-3.5 group flex-shrink-0">
          <div
            className="w-[60px] h-[60px] rounded-xl overflow-hidden flex items-center justify-center p-1 transition-all duration-300 group-hover:shadow-[0_0_20px_var(--neon)]"
            style={{
              border: "1px solid var(--border-hover)",
              background: "var(--bg-card)",
            }}
          >
            <img
              src="/assets/Logo.png"
              alt="LGA FORTECH Logo"
              className="w-full h-full object-contain rounded-lg"
            />
          </div>
          <span
            className="font-bold tracking-widest text-base uppercase"
            style={{ color: "var(--text-primary)" }}
          >
            LGA<span style={{ color: "var(--neon)" }}>FORTECH</span>
          </span>
        </a>

        {/* Desktop links */}
        <ul className="hidden md:flex items-center gap-5 flex-1 justify-center">
          {navLinks.map(({ href, label, target }) => {
            const id = href.startsWith("#") ? href.replace("#", "") : "";
            const isActive = id ? activeSection === id : false;
            return (
              <li key={href}>
                <a
                  href={href}
                  target={target}
                  rel={target ? "noopener noreferrer" : undefined}
                  className="nav-link text-xs font-medium tracking-wider uppercase transition-colors duration-300 inline-flex items-center gap-1"
                  style={{
                    color: isActive ? "var(--neon)" : "var(--text-muted)",
                  }}
                >
                  {label}
                  {target && (
                    <svg className="w-3 h-3 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                  )}
                  {isActive && (
                    <span
                      className="absolute -bottom-1 left-0 right-0 h-px"
                      style={{
                        background: "var(--neon)",
                        boxShadow: "0 0 8px var(--neon)",
                      }}
                    />
                  )}
                </a>
              </li>
            );
          })}
        </ul>

        {/* Right controls */}
        <div className="flex items-center gap-3 flex-shrink-0">
          {/* Theme toggle */}
          <ThemeToggle />

          {/* WhatsApp CTA — desktop */}
          <a
            href="https://api.whatsapp.com/send?phone=5534998972575&text=Ol%C3%A1%2C%20Preciso%20de%20informa%C3%A7%C3%B5es%20sobre%20Site."
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:inline-flex items-center gap-1.5 btn-neon px-4 py-2 rounded-lg text-xs font-semibold tracking-wider uppercase"
          >
            <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
            WhatsApp
          </a>

          {/* Hamburger — mobile */}
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            className="md:hidden flex flex-col gap-1.5 p-2 rounded-lg transition-colors"
            style={{
              border: "1px solid var(--border-hover)",
              color: "var(--text-primary)",
            }}
            aria-label="Menu"
          >
            <span
              className={`block w-5 h-px transition-all duration-300 ${menuOpen ? "rotate-45 translate-y-2" : ""}`}
              style={{ background: "var(--text-primary)" }}
            />
            <span
              className={`block w-5 h-px transition-all duration-300 ${menuOpen ? "opacity-0" : ""}`}
              style={{ background: "var(--text-primary)" }}
            />
            <span
              className={`block w-5 h-px transition-all duration-300 ${menuOpen ? "-rotate-45 -translate-y-2" : ""}`}
              style={{ background: "var(--text-primary)" }}
            />
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        className={`md:hidden transition-all duration-300 overflow-hidden ${menuOpen ? "max-h-96 opacity-100" : "max-h-0 opacity-0"}`}
      >
        <div
          className="px-6 py-4 flex flex-col gap-4"
          style={{
            background: isDark ? "rgba(2,4,8,0.95)" : "rgba(240,244,255,0.97)",
            backdropFilter: "blur(20px)",
            borderTop: "1px solid var(--border)",
          }}
        >
          {navLinks.map(({ href, label, target }) => (
            <a
              key={href}
              href={href}
              target={target}
              rel={target ? "noopener noreferrer" : undefined}
              onClick={() => setMenuOpen(false)}
              className="text-sm font-medium tracking-wider uppercase transition-colors duration-300 hover:underline inline-flex items-center gap-1.5"
              style={{ color: "var(--text-muted)" }}
            >
              {label}
              {target && (
                <svg className="w-3.5 h-3.5 opacity-70" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                </svg>
              )}
            </a>
          ))}
          <a
            href="https://api.whatsapp.com/send?phone=5534998972575"
            target="_blank"
            rel="noopener noreferrer"
            className="btn-neon inline-flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold tracking-wider uppercase mt-2"
          >
            WhatsApp
          </a>
        </div>
      </div>
    </header>
  );
}
