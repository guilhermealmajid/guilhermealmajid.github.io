import { useState } from 'react'
import p1 from '/assets/projects1-pPohZ17t.webp'
import p2 from '/assets/projects2-BPUxHM7x.webp'
import p3 from '/assets/projects3-BvhK26dG.webp'
import p4 from '/assets/projects4-vb4Iu5JA.webp'
import p5 from '/assets/projects5-Bf8-gK4B.webp'
import p6 from '/assets/projects6-CcdMQfsJ.webp'
import pPontosDeAmor from '/assets/SitePontosdeAmor.png'

const projects = [
  {
    name: 'Pontos de Amor',
    description: 'Ateliê de Crochê Artesanal por Layla Almeida. Peças tecidas à mão, moda praia, bolsas contemporâneas e catálogo interativo.',
    image: pPontosDeAmor,
    link: 'https://lgafortech.com.br/pontosdeamor/',
    tags: ['React', 'Tailwind', 'Landing Page', 'Artesanal'],
    category: 'Landing Page'
  },
  { name: 'Portfólio One',      description: 'Site Interativo, Letreiro Digital, Área Contato, Links Redes Sociais, Site Landing Page!', image: p1, link: 'https://portfolio-ones.netlify.app/', tags: ['React', 'Tailwind', 'Animação'],   category: 'Landing Page' },
  { name: 'Web App Moderno',    description: 'Aplicação Web completa com design moderno, conteúdos dinâmicos e projetos escalonáveis.',    image: p2, link: '#', tags: ['Next.js', 'TypeScript', 'API'],          category: 'Web App'    },
  { name: 'Sistema Empresarial',description: 'Solução de Negócios personalizada com código limpo e arquitetura moderna.',                   image: p3, link: '#', tags: ['React', 'Node.js', 'Database'],          category: 'Sistema'    },
  { name: 'E-commerce',         description: 'Loja virtual com carrinho, checkout e integração com meios de pagamento.',                    image: p4, link: '#', tags: ['Next.js', 'Stripe', 'SEO'],             category: 'E-commerce' },
  { name: 'Dashboard Analytics',description: 'Painel de controle com gráficos, relatórios e dados em tempo real.',                          image: p5, link: '#', tags: ['React', 'Chart.js', 'REST API'],         category: 'Dashboard'  },
  { name: 'Site Corporativo',   description: 'Presença digital profissional com identidade visual forte e responsiva.',                      image: p6, link: '#', tags: ['React', 'Framer Motion', 'CMS'],        category: 'Corporativo'},
]

const categories = ['Todos', ...new Set(projects.map(p => p.category))]

export default function Work() {
  const [activeCategory, setActiveCategory] = useState('Todos')
  const [hoveredIndex, setHoveredIndex] = useState(null)

  const filtered = activeCategory === 'Todos'
    ? projects
    : projects.filter(p => p.category === activeCategory)

  return (
    <section id="work" className="py-24 relative overflow-hidden">
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-72 h-72 rounded-full blur-[120px] pointer-events-none orb-2" style={{ background: 'var(--orb2)' }} />

      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <span className="text-sm font-mono" style={{ color: 'var(--neon)', opacity: 0.5 }}>02.</span>
          <h2 className="text-3xl md:text-4xl font-bold" style={{ color: 'var(--text-primary)' }}>
            Nosso <span className="gradient-text">Portifólio</span>
          </h2>
          <div className="flex-1 h-px" style={{ background: 'linear-gradient(to right, var(--neon), transparent)', opacity: 0.2 }} />
        </div>

        <p className="text-sm md:text-base mb-10 max-w-2xl" style={{ color: 'var(--text-muted)' }}>
          Nossa Proposta e Diferencial é a confecção de cada Projeto com{' '}
          <span className="font-medium" style={{ color: 'var(--text-primary)' }}>Programação de código limpo</span>,
          Conteúdos Dinâmicos, Projetos Escalonáveis junto ao Cliente para expansão do seu Negócio de forma continuada.
        </p>

        {/* Filter tabs */}
        <div className="flex flex-wrap gap-2 mb-10">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className="px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase transition-all duration-300"
              style={
                activeCategory === cat
                  ? { color: 'var(--neon)', background: 'var(--orb1)', border: '1px solid var(--border-hover)', boxShadow: '0 0 15px var(--orb1)' }
                  : { color: 'var(--text-subtle)', background: 'transparent', border: '1px solid var(--border)' }
              }
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((project, i) => (
            <div
              key={project.name}
              className="group glass border-neon rounded-2xl overflow-hidden card-shine transition-all duration-500"
              style={{ cursor: 'default' }}
              onMouseEnter={() => setHoveredIndex(i)}
              onMouseLeave={() => setHoveredIndex(null)}
            >
              {/* Image */}
              <div className="relative h-48 img-hover-zoom overflow-hidden">
                <img src={project.image} alt={project.name} className="w-full h-full object-cover" />
                <div className="absolute inset-0" style={{ background: `linear-gradient(to top, var(--bg-card-solid), transparent)` }} />
                <div className="absolute top-3 left-3">
                  <span className="text-xs px-2 py-0.5 rounded-full backdrop-blur-sm" style={{ color: 'var(--neon)', background: 'var(--orb1)', border: '1px solid var(--border)' }}>
                    {project.category}
                  </span>
                </div>
                {hoveredIndex === i && (
                  <div className="absolute inset-0" style={{ background: 'var(--orb1)' }} />
                )}
              </div>

              {/* Content */}
              <div className="p-5 space-y-3">
                <h3 className="text-base font-bold transition-colors duration-300" style={{ color: hoveredIndex === i ? 'var(--neon)' : 'var(--text-primary)' }}>
                  {project.name}
                </h3>
                <p className="text-xs leading-relaxed" style={{ color: 'var(--text-subtle)' }}>{project.description}</p>

                <div className="flex flex-wrap gap-1.5">
                  {project.tags.map(tag => (
                    <span key={tag} className="text-xs px-2 py-0.5 rounded-full" style={{ color: 'var(--purple)', background: 'var(--orb2)', border: '1px solid var(--border)' }}>
                      {tag}
                    </span>
                  ))}
                </div>

                {project.link !== '#' && (
                  <a href={project.link} target="_blank" rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-medium mt-2 transition-colors duration-300"
                    style={{ color: 'var(--neon)' }}>
                    Visitar Site
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                  </a>
                )}
              </div>

              {/* Bottom glow line */}
              <div className="h-0.5 transition-all duration-500" style={{
                background: hoveredIndex === i ? 'linear-gradient(to right, var(--neon), var(--purple))' : 'transparent',
              }} />
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="mt-12 text-center">
          <a
            href="https://api.whatsapp.com/send?phone=5534998972575&text=Ol%C3%A1%2C%20quero%20um%20projeto"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 btn-neon px-8 py-3 rounded-xl text-sm font-bold tracking-wider uppercase"
          >
            Solicitar Orçamento
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
            </svg>
          </a>
        </div>
      </div>
    </section>
  )
}
