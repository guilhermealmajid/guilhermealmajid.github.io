import { useState } from 'react'

const contactItems = [
  {
    icon: (
      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
      </svg>
    ),
    label: 'WhatsApp',
    value: '+55 34 99897-2575',
    href: 'https://api.whatsapp.com/send?phone=5534998972575&text=Ol%C3%A1%2C%20Preciso%20de%20maiores%20informa%C3%A7%C3%B5es%20%E2%84%B9%EF%B8%8F%20sobre%20Site.',
    color: 'text-green-400 bg-green-400/10 border-green-400/20',
  },
  {
    icon: (
      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
      </svg>
    ),
    label: 'Email',
    value: 'lgafortech@gmail.com',
    href: 'mailto:lgafortech@gmail.com',
    color: 'text-cyan-400 bg-cyan-400/10 border-cyan-400/20',
  },
  {
    icon: (
      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
        <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
      </svg>
    ),
    label: 'Instagram',
    value: '@lgafortech',
    href: 'https://www.instagram.com/lgafortech/',
    color: 'text-pink-400 bg-pink-400/10 border-pink-400/20',
  },
]

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' })
  const [sent, setSent] = useState(false)

  const handleChange = e => setForm(f => ({ ...f, [e.target.name]: e.target.value }))

  const handleSubmit = e => {
    e.preventDefault()
    const text = encodeURIComponent(
      `Olá! Me chamo ${form.name} (${form.email}).\n\n${form.message}`
    )
    window.open(`https://api.whatsapp.com/send?phone=5534998972575&text=${text}`, '_blank')
    setSent(true)
    setTimeout(() => setSent(false), 3000)
  }

  return (
    <section id="contact" className="py-24 relative overflow-hidden">
      {/* Background accent */}
      <div className="absolute left-1/2 bottom-0 -translate-x-1/2 w-96 h-48 bg-cyan-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="flex items-center gap-4 mb-16">
          <span className="text-sm font-mono" style={{ color: 'var(--neon)', opacity: 0.5 }}>05.</span>
          <h2 className="text-3xl md:text-4xl font-bold" style={{ color: 'var(--text-primary)' }}>
            Vamos <span className="gradient-text">Conversar</span>
          </h2>
          <div className="flex-1 h-px bg-gradient-to-r from-cyan-400/20 to-transparent" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          {/* Left: info */}
          <div className="space-y-8">
            <div>
              <p className="leading-relaxed text-sm md:text-base mb-6" style={{ color: 'var(--text-muted)' }}>
                Estou animado para colaborar em projetos que ultrapassam limites e criam
                impacto significativo.{' '}
                <span className="font-medium" style={{ color: 'var(--text-primary)' }}>
                  Vamos construir algo inovador e excepcional juntos!
                </span>
              </p>
            </div>

            {/* Contact items */}
            <div className="space-y-4">
              {contactItems.map(item => (
                <a
                  key={item.label}
                  href={item.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 glass border-neon hover:border-cyan-400/40 rounded-xl p-4 transition-all duration-300 group"
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center border ${item.color} flex-shrink-0 group-hover:scale-110 transition-transform duration-300`}>
                    {item.icon}
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-widest" style={{ color: 'var(--text-subtle)' }}>{item.label}</div>
                    <div className="text-sm font-medium" style={{ color: 'var(--text-primary)' }}>{item.value}</div>
                  </div>
                  <svg className="w-4 h-4 ml-auto transition-colors duration-300" style={{ color: 'var(--text-subtle)' }} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                  </svg>
                </a>
              ))}
            </div>

            {/* Partnership card */}
            <div className="glass border-neon rounded-2xl p-6 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/5 to-purple-500/5" />
              <div className="relative">
                <h4 className="text-base font-bold mb-2" style={{ color: 'var(--text-primary)' }}>Parceria de Negócios</h4>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--text-muted)' }}>
                  Somos parceiros ao desenvolvimento contínuo dos seus Projetos de Negócios
                  com Desenvolvimento de Sites e com suporte T.I. Conte conosco!
                </p>
                <div className="mt-4 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full pulse-ring" style={{ background: 'var(--neon)' }} />
                  <span className="text-xs font-medium" style={{ color: 'var(--neon)' }}>Disponível para projetos</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right: form */}
          <div className="glass border-neon rounded-2xl p-6 md:p-8">
            <h3 className="text-sm font-mono uppercase tracking-widest mb-6" style={{ color: 'var(--neon)', opacity: 0.6 }}>
              &#47;&#47; Enviar Mensagem
            </h3>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-1">
                <label className="text-xs uppercase tracking-widest" style={{ color: 'var(--text-subtle)' }}>Seu Nome</label>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  required
                  placeholder="Como posso te chamar?"
                  className="w-full rounded-xl px-4 py-3 text-sm outline-none transition-colors duration-300 border"
                  style={{
                    background: 'var(--bg-input)',
                    borderColor: 'var(--border)',
                    color: 'var(--text-primary)',
                  }}
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs uppercase tracking-widest" style={{ color: 'var(--text-subtle)' }}>Email</label>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  required
                  placeholder="seu@email.com"
                  className="w-full rounded-xl px-4 py-3 text-sm outline-none transition-colors duration-300 border"
                  style={{
                    background: 'var(--bg-input)',
                    borderColor: 'var(--border)',
                    color: 'var(--text-primary)',
                  }}
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs uppercase tracking-widest" style={{ color: 'var(--text-subtle)' }}>Mensagem</label>
                <textarea
                  name="message"
                  value={form.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  placeholder="Conte sobre seu projeto..."
                  className="w-full rounded-xl px-4 py-3 text-sm outline-none transition-colors duration-300 resize-none border"
                  style={{
                    background: 'var(--bg-input)',
                    borderColor: 'var(--border)',
                    color: 'var(--text-primary)',
                  }}
                />
              </div>

              <button
                type="submit"
                className={`w-full py-3 rounded-xl text-sm font-bold tracking-wider uppercase transition-all duration-300 ${
                  sent
                    ? 'bg-green-500/20 text-green-400 border border-green-500/30'
                    : 'btn-solid'
                }`}
              >
                {sent ? '✓ Mensagem Enviada!' : 'Enviar via WhatsApp →'}
              </button>

              <p className="text-xs text-center" style={{ color: 'var(--text-subtle)' }}>
                Sua mensagem será enviada via WhatsApp para resposta rápida.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  )
}
