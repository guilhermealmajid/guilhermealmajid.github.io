const experiences = [
  {
    role: 'Desenvolvedor FrontEnd & Fundador',
    company: 'LGA FORTECH',
    period: '2020 — Presente',
    type: 'Empreendedorismo',
    description: 'Criação de Aplicativos Web Modernos com Programação de Alto Nível - React, Next.js, Tailwind CSS. Nossa Proposta e Diferencial é a confecção de cada Projeto com Programação de código limpo, Conteúdos Dinâmicos e Projetos Escalonáveis.',
    skills: ['React', 'Next.js', 'Tailwind CSS', 'Framer Motion', 'Node.js'],
    highlight: true,
  },
  {
    role: 'Técnico em Telecomunicações',
    company: 'Grande Operadora Telecom',
    period: '+20 Anos',
    type: 'Emprego',
    description: 'Implementação e Manutenção de Dados e Telefonia para clientes, nas diversas Tecnologias Radio, Satélite, Fibra Óptica. Gerenciamento de equipes e projetos de infraestrutura.',
    skills: ['Fibra Óptica', 'Rádio', 'Satélite', 'Dados', 'Telefonia'],
    highlight: false,
  },
]

const services = [
  {
    icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>,
    title: 'Desenvolvimento Web',
    description: 'Aplicativos Web Modernos com React, Next.js e Tailwind CSS. Código limpo, performático e escalável.',
    accent: 'var(--neon)',
    bg: 'var(--orb1)',
  },
  {
    icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" /></svg>,
    title: 'Design Responsivo',
    description: 'Interfaces adaptadas para todos os dispositivos — mobile, tablet e desktop. UX/UI moderno e intuitivo.',
    accent: 'var(--purple)',
    bg: 'var(--orb2)',
  },
  {
    icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" /></svg>,
    title: 'Suporte T.I',
    description: 'Suporte técnico especializado em T.I, Telecomunicações, Fibra Óptica e infraestrutura de redes.',
    accent: '#3b82f6',
    bg: 'rgba(59,130,246,0.05)',
  },
  {
    icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>,
    title: 'Alta Performance',
    description: 'Sites otimizados para velocidade máxima, SEO e Core Web Vitals. Experiência rápida e imersiva.',
    accent: 'var(--neon)',
    bg: 'var(--orb1)',
  },
]

export default function Experience() {
  return (
    <section id="experience" className="py-24 relative overflow-hidden">
      <div className="absolute left-1/2 top-0 -translate-x-1/2 w-96 h-96 rounded-full blur-[120px] pointer-events-none" style={{ background: 'rgba(59,130,246,0.04)' }} />

      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="flex items-center gap-4 mb-16">
          <span className="text-sm font-mono" style={{ color: 'var(--neon)', opacity: 0.5 }}>03.</span>
          <h2 className="text-3xl md:text-4xl font-bold" style={{ color: 'var(--text-primary)' }}>
            Experiência & <span className="gradient-text">Serviços</span>
          </h2>
          <div className="flex-1 h-px" style={{ background: 'linear-gradient(to right, var(--neon), transparent)', opacity: 0.2 }} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Timeline */}
          <div>
            <h3 className="text-sm font-mono uppercase tracking-widest mb-8" style={{ color: 'var(--neon)', opacity: 0.6 }}>
              &#47;&#47; Trajetória Profissional
            </h3>
            <div className="relative space-y-8">
              {/* vertical line */}
              <div className="absolute left-4 top-0 bottom-0 w-px" style={{ background: 'linear-gradient(to bottom, var(--neon), var(--purple), transparent)', opacity: 0.3 }} />

              {experiences.map((exp, i) => (
                <div key={i} className="relative pl-12">
                  {/* Dot */}
                  <div className={`absolute left-0 top-1 w-8 h-8 rounded-full flex items-center justify-center`}
                    style={{
                      background: exp.highlight ? 'var(--orb1)' : 'var(--bg-card)',
                      border: `1px solid ${exp.highlight ? 'var(--border-hover)' : 'var(--border)'}`,
                      boxShadow: exp.highlight ? '0 0 15px var(--orb1)' : 'none',
                    }}>
                    <div className="w-2 h-2 rounded-full" style={{ background: exp.highlight ? 'var(--neon)' : 'var(--text-subtle)' }} />
                  </div>

                  <div className="glass rounded-xl p-5 transition-all duration-300 hover:shadow-lg"
                    style={{ border: `1px solid ${exp.highlight ? 'var(--border-hover)' : 'var(--border)'}` }}>
                    <div className="flex flex-wrap items-start justify-between gap-2 mb-2">
                      <div>
                        <h4 className="text-base font-bold" style={{ color: 'var(--text-primary)' }}>{exp.role}</h4>
                        <div className="text-sm font-medium" style={{ color: 'var(--neon)' }}>{exp.company}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs font-mono" style={{ color: 'var(--text-subtle)' }}>{exp.period}</div>
                        <span className="text-xs px-2 py-0.5 rounded-full" style={{ color: 'var(--text-subtle)', background: 'var(--bg-card)', border: '1px solid var(--border)' }}>
                          {exp.type}
                        </span>
                      </div>
                    </div>
                    <p className="text-sm leading-relaxed mb-3" style={{ color: 'var(--text-muted)' }}>{exp.description}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {exp.skills.map(skill => (
                        <span key={skill} className="text-xs px-2 py-0.5 rounded-md" style={{ color: 'var(--text-muted)', background: 'var(--bg-card)', border: '1px solid var(--border)' }}>
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h3 className="text-sm font-mono uppercase tracking-widest mb-8" style={{ color: 'var(--neon)', opacity: 0.6 }}>
              &#47;&#47; O Que Oferecemos
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {services.map((service, i) => (
                <div key={i} className="glass rounded-xl p-5 card-shine transition-all duration-300"
                  style={{ border: '1px solid var(--border)', cursor: 'default' }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = service.accent}
                  onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
                >
                  <div className="w-10 h-10 rounded-lg flex items-center justify-center mb-3"
                    style={{ color: service.accent, background: service.bg, border: `1px solid ${service.accent}22` }}>
                    {service.icon}
                  </div>
                  <h4 className="text-sm font-bold mb-2" style={{ color: 'var(--text-primary)' }}>{service.title}</h4>
                  <p className="text-xs leading-relaxed" style={{ color: 'var(--text-subtle)' }}>{service.description}</p>
                </div>
              ))}
            </div>

            {/* CTA card */}
            <div className="mt-6 glass rounded-xl p-6 relative overflow-hidden" style={{ border: '1px solid var(--border-hover)', opacity: 1 }}>
              <div className="absolute inset-0 shimmer" />
              <div className="relative">
                <p className="text-sm leading-relaxed mb-4" style={{ color: 'var(--text-muted)' }}>
                  <span className="font-semibold" style={{ color: 'var(--neon)' }}>Somos parceiros</span> ao desenvolvimento
                  contínuo dos seus Projetos de Negócios com Desenvolvimento de Sites e com suporte T.I,
                  conte conosco! Um Grande Abraço! 🚀
                </p>
                <a href="#contact" className="inline-flex items-center gap-1 text-xs font-semibold transition-colors duration-300" style={{ color: 'var(--neon)' }}>
                  Vamos Conversar →
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
