import { useState, useEffect } from "react";
import bgImage from "/assets/jason-root-BQwdWAqX.webp";
import { useTheme } from "../context/ThemeContext";

const typingWords = [
  "Sites Artesanais",
  "Código Limpo",
  "React & Next.js",
  "Alta Performance",
  "UX Moderno",
];

function useTypingEffect(words, speed = 80, pause = 1800) {
  const [displayText, setDisplayText] = useState("");
  const [wordIndex, setWordIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  useEffect(() => {
    const currentWord = words[wordIndex % words.length];
    const timeout = setTimeout(
      () => {
        if (!isDeleting) {
          setDisplayText(currentWord.substring(0, displayText.length + 1));
          if (displayText.length === currentWord.length) {
            setTimeout(() => setIsDeleting(true), pause);
          }
        } else {
          setDisplayText(currentWord.substring(0, displayText.length - 1));
          if (displayText.length === 0) {
            setIsDeleting(false);
            setWordIndex((i) => i + 1);
          }
        }
      },
      isDeleting ? speed / 2 : speed,
    );
    return () => clearTimeout(timeout);
  }, [displayText, isDeleting, wordIndex, words, speed, pause]);

  return displayText;
}

function StatItem({ value, label }) {
  return (
    <div className="text-center">
      <div
        className="text-2xl md:text-3xl font-bold text-glow"
        style={{ color: "var(--neon)" }}
      >
        {value}
      </div>
      <div
        className="text-xs uppercase tracking-widest mt-1"
        style={{ color: "var(--text-subtle)" }}
      >
        {label}
      </div>
    </div>
  );
}

export default function Hero() {
  const { isDark } = useTheme();
  const typedText = useTypingEffect(typingWords);

  return (
    <section
      id="home"
      className="mt-3 relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Background image */}
      <div className="absolute inset-0">
        <img
          src={bgImage}
          alt="Background"
          className={`w-full h-full object-cover ${isDark ? "opacity-20" : "opacity-10"}`}
        />
        <div
          className="absolute inset-0"
          style={{
            background: isDark
              ? "linear-gradient(to bottom, rgba(2,4,8,0.6) 0%, rgba(2,4,8,0.4) 50%, rgba(2,4,8,1) 100%)"
              : "linear-gradient(to bottom, rgba(240,244,255,0.8) 0%, rgba(240,244,255,0.5) 50%, rgba(240,244,255,1) 100%)",
          }}
        />
      </div>

      {/* Grid */}
      <div className="absolute inset-0 grid-bg opacity-60" />

      {/* Orbs */}
      <div
        className="absolute top-1/4 left-1/4 w-96 h-96 rounded-full blur-[120px] orb-1 pointer-events-none"
        style={{ background: "var(--orb1)" }}
      />
      <div
        className="absolute bottom-1/3 right-1/4 w-80 h-80 rounded-full blur-[100px] orb-2 pointer-events-none"
        style={{ background: "var(--orb2)" }}
      />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-28 md:pt-36 pb-12 flex flex-col items-center text-center">
        {/* Hero Logo Card */}
        <div className="mb-8 flex flex-col items-center group">
          <div className="relative p-1 rounded-3xl transition-transform duration-500 hover:scale-105">
            <div
              className="absolute -inset-2 rounded-3xl blur-xl opacity-60 transition duration-500 group-hover:opacity-90 pointer-events-none"
              style={{
                background:
                  "linear-gradient(135deg, var(--neon) 0%, #8b5cf6 50%, var(--neon) 100%)",
              }}
            />
            <div
              className="relative rounded-2xl p-4 md:p-6 overflow-hidden flex items-center justify-center border transition-all duration-300"
              style={{
                background: "var(--bg-card)",
                borderColor: "var(--border-hover)",
                boxShadow: "0 10px 40px -10px var(--neon)",
              }}
            >
              <img
                src="/assets/Logo.png"
                alt="LGA FORTECH Logo"
                className="h-44 sm:h-56 md:h-72 w-auto object-contain rounded-xl"
              />
            </div>
          </div>
        </div>

        {/* Badge */}
        <div className="inline-flex items-center gap-2 glass border-neon rounded-full px-4 py-1.5 mb-8">
          <span
            className="w-2 h-2 rounded-full pulse-ring"
            style={{ background: "var(--neon)" }}
          />
          <span
            className="text-xs font-medium tracking-wider uppercase"
            style={{ color: "var(--neon)" }}
          >
            Disponível para Projetos
          </span>
        </div>

        {/* Headline */}
        <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold leading-tight tracking-tight mb-4">
          <span style={{ color: "var(--text-primary)" }} className="block">
            Bem-vindos!
          </span>
          <span className="gradient-text block mt-2">
            {typedText}
            <span className="cursor-blink" style={{ color: "var(--neon)" }}>
              |
            </span>
          </span>
        </h1>

        {/* Subtitle */}
        <p
          className="max-w-2xl text-base md:text-lg leading-relaxed mb-10 mt-4"
          style={{ color: "var(--text-muted)" }}
        >
          Criação de{" "}
          <span
            className="font-medium"
            style={{ color: "var(--text-primary)" }}
          >
            Aplicativos Web Modernos
          </span>{" "}
          com Programação de Alto Nível — React, Next.js, Tailwind CSS. Projetos
          Escalonáveis, Código Limpo e Entrega de Qualidade.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row gap-4 mb-16">
          <a
            href="#work"
            className="btn-solid inline-flex items-center gap-2 px-8 py-3 rounded-xl text-sm font-bold tracking-wider uppercase"
          >
            Ver Portifólio
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M13 7l5 5m0 0l-5 5m5-5H6"
              />
            </svg>
          </a>
          <a
            href="#contact"
            className="btn-neon inline-flex items-center gap-2 px-8 py-3 rounded-xl text-sm font-bold tracking-wider uppercase"
          >
            Entrar em Contato
          </a>
        </div>

        {/* Stats */}
        <div className="glass border-neon rounded-2xl px-8 py-6 flex flex-wrap justify-center gap-10">
          <StatItem value="+20" label="Anos de T.I" />
          <div className="w-px" style={{ background: "var(--border-hover)" }} />
          <StatItem value="100%" label="Código Limpo" />
          <div className="w-px" style={{ background: "var(--border-hover)" }} />
          <StatItem value="∞" label="Suporte" />
        </div>

        {/* Scroll indicator */}
        <div className="mt-12 flex flex-col items-center gap-2 opacity-40">
          <span
            className="text-xs uppercase tracking-widest"
            style={{ color: "var(--text-subtle)" }}
          >
            Scroll
          </span>
          <div
            className="w-px h-10"
            style={{
              background:
                "linear-gradient(to bottom, var(--neon), transparent)",
            }}
          />
        </div>
      </div>
    </section>
  );
}
