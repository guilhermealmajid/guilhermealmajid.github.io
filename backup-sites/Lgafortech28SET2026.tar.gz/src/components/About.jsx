import guilhermeImg from "/assets/guilherme-DLqjQXFK.jpeg";

const skills = [
  { name: "React.js", level: 92 },
  { name: "Next.js", level: 88 },
  { name: "Tailwind CSS", level: 95 },
  { name: "Framer Motion", level: 82 },
  { name: "Node.js", level: 75 },
  { name: "TypeScript", level: 78 },
];

const techBadges = [
  "React",
  "Next.js",
  "Tailwind",
  "Framer Motion",
  "Node.js",
  "JavaScript",
  "TypeScript",
  "Git",
  "Figma",
  "Vite",
];

function SkillBar({ name, level, index }) {
  return (
    <div className="space-y-1.5">
      <div className="flex justify-between items-center">
        <span
          className="text-sm font-medium"
          style={{ color: "var(--text-primary)" }}
        >
          {name}
        </span>
        <span className="text-xs font-bold" style={{ color: "var(--neon)" }}>
          {level}%
        </span>
      </div>
      <div
        className="h-1.5 rounded-full overflow-hidden"
        style={{ background: "var(--skill-track)" }}
      >
        <div
          className="h-full rounded-full"
          style={{
            width: `${level}%`,
            background: "linear-gradient(to right, var(--neon), var(--purple))",
            boxShadow: "0 0 8px var(--neon)",
            transition: `width 1.2s cubic-bezier(0.4,0,0.2,1) ${index * 0.1}s`,
          }}
        />
      </div>
    </div>
  );
}

export default function About() {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      {/* Background accent */}
      <div
        className="absolute left-0 top-1/2 -translate-y-1/2 w-72 h-72 rounded-full blur-[100px] pointer-events-none orb-1"
        style={{ background: "var(--orb1)" }}
      />

      <div className="max-w-7xl mx-auto px-6">
        {/* Section header */}
        <div className="flex items-center gap-4 mb-16">
          <span
            className="text-sm font-mono"
            style={{ color: "var(--neon)", opacity: 0.5 }}
          >
            01.
          </span>
          <h2
            className="text-3xl md:text-4xl font-bold"
            style={{ color: "var(--text-primary)" }}
          >
            Sobre o <span className="gradient-text">Desenvolvedor</span>
          </h2>
          <div
            className="flex-1 h-px"
            style={{
              background: "linear-gradient(to right, var(--neon), transparent)",
              opacity: 0.2,
            }}
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Image */}
          <div className="flex justify-center md:justify-start">
            <div className="relative">
              <div
                className="absolute inset-0 rounded-2xl blur-xl scale-110"
                style={{
                  background:
                    "linear-gradient(to bottom right, var(--orb1), var(--orb2))",
                }}
              />
              <div
                className="absolute -inset-1 rounded-2xl"
                style={{
                  border: "1px solid var(--border-hover)",
                  opacity: 0.4,
                }}
              />

              <div
                className="relative w-64 h-64 md:w-80 md:h-80 rounded-2xl overflow-hidden"
                style={{ border: "1px solid var(--border)" }}
              >
                <img
                  src={guilhermeImg}
                  alt="Guilherme Almeida"
                  className="w-full h-full object-cover"
                />
                <div
                  className="absolute inset-0"
                  style={{
                    background:
                      "linear-gradient(to top, var(--bg) 0%, transparent 50%)",
                  }}
                />
              </div>

              <div className="absolute -bottom-4 -right-4 glass border-neon rounded-xl px-4 py-2">
                <div
                  className="text-xs"
                  style={{ color: "var(--text-subtle)" }}
                >
                  Fundador
                </div>
                <div
                  className="text-sm font-bold"
                  style={{ color: "var(--neon)" }}
                >
                  LGA FORTECH
                </div>
              </div>

              <div className="absolute -top-4 -left-4 glass border-neon rounded-xl px-3 py-2 float-anim">
                <div
                  className="text-xs"
                  style={{ color: "var(--text-subtle)" }}
                >
                  Experiência
                </div>
                <div
                  className="text-sm font-bold"
                  style={{ color: "var(--text-primary)" }}
                >
                  +20 Anos
                </div>
              </div>
            </div>
          </div>

          {/* Content */}
          <div className="space-y-6">
            <div className="space-y-4">
              <h3
                className="text-xl font-bold"
                style={{ color: "var(--text-primary)" }}
              >
                Guilherme Almeida
                <span
                  className="ml-2 text-xs font-mono px-2 py-0.5 rounded-full"
                  style={{
                    color: "var(--neon)",
                    background: "var(--orb1)",
                    border: "1px solid var(--border-hover)",
                  }}
                >
                  FrontEnd Dev
                </span>
              </h3>
              <p
                className="leading-relaxed text-sm md:text-base"
                style={{ color: "var(--text-muted)" }}
              >
                Desenvolvedor FrontEnd e Fundador da LGA-FORTECH atuando mais de
                20 anos com T.I, Telecomunicações e Aplicações Web.
              </p>
              <p
                className="leading-relaxed text-sm md:text-base"
                style={{ color: "var(--text-muted)" }}
              >
                Ser Empreendedor é aperfeiçoamento contínuo, aprendendo dia a
                dia nessa jornada profissional há{" "}
                <span
                  className="font-semibold"
                  style={{ color: "var(--neon)" }}
                >
                  +20 anos
                </span>{" "}
                entregando soluções de Negócios aos Clientes. Nossas aplicações
                Web vem trazer uma experiência imersiva com uso de Tecnologias
                mais recentes como{" "}
                <span
                  className="font-medium"
                  style={{ color: "var(--text-primary)" }}
                >
                  ReactJS, NextJS, TailwindCSS
                </span>{" "}
                e FramerMotion.
              </p>
              <div className="glass border-neon rounded-xl p-4">
                <p
                  className="text-sm italic"
                  style={{ color: "var(--neon)", opacity: 0.8 }}
                >
                  "Estou animado para colaborar em projetos que ultrapassam
                  limites e criam impacto significativo. Vamos construir algo
                  inovador e excepcional juntos."
                </p>
              </div>
            </div>

            {/* Skill bars */}
            {/* <div className="space-y-3"> */}
            {/*   {skills.map((skill, i) => ( */}
            {/*     <SkillBar key={skill.name} {...skill} index={i} /> */}
            {/*   ))} */}
            {/* </div> */}
            {/**/}

            {/* Tech badges */}

            {/* <div className="flex flex-wrap gap-2 pt-2"> */}
            {/*   {techBadges.map((tech) => ( */}
            {/*     <span */}
            {/*       key={tech} */}
            {/*       className="text-xs px-3 py-1 rounded-full transition-colors duration-300" */}
            {/*       style={{ */}
            {/*         color: "var(--text-muted)", */}
            {/*         background: "var(--bg-card)", */}
            {/*         border: "1px solid var(--border)", */}
            {/*       }} */}
            {/*     > */}
            {/*       {tech} */}
            {/*     </span> */}
            {/*   ))} */}
            {/* </div> */}
            {/**/}

            {/* Social links */}
            {/* <div className="flex gap-3 pt-2"> */}
            {/*   {[ */}
            {/*     { */}
            {/*       href: "https://www.instagram.com/lgafortech/", */}
            {/*       icon: ( */}
            {/*         <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" /> */}
            {/*       ), */}
            {/*       fill: true, */}
            {/*     }, */}
            {/*     { */}
            {/*       href: "mailto:lgafortech@gmail.com", */}
            {/*       icon: ( */}
            {/*         <path */}
            {/*           strokeLinecap="round" */}
            {/*           strokeLinejoin="round" */}
            {/*           strokeWidth={1.5} */}
            {/*           d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" */}
            {/*         /> */}
            {/*       ), */}
            {/*       fill: false, */}
            {/*     }, */}
            {/*     { */}
            {/*       href: "https://api.whatsapp.com/send?phone=5534998972575", */}
            {/*       icon: ( */}
            {/*         <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" /> */}
            {/*       ), */}
            {/*       fill: true, */}
            {/*     }, */}
            {/*   ].map(({ href, icon, fill }, i) => ( */}
            {/*     <a */}
            {/*       key={i} */}
            {/*       href={href} */}
            {/*       target="_blank" */}
            {/*       rel="noopener noreferrer" */}
            {/*       className="w-10 h-10 glass border-neon rounded-lg flex items-center justify-center transition-all duration-300" */}
            {/*       style={{ color: "var(--text-muted)" }} */}
            {/*       onMouseEnter={(e) => { */}
            {/*         e.currentTarget.style.color = "var(--neon)"; */}
            {/*         e.currentTarget.style.borderColor = "var(--border-hover)"; */}
            {/*       }} */}
            {/*       onMouseLeave={(e) => { */}
            {/*         e.currentTarget.style.color = "var(--text-muted)"; */}
            {/*         e.currentTarget.style.borderColor = "var(--border)"; */}
            {/*       }} */}
            {/*     > */}
            {/*       <svg */}
            {/*         className="w-4 h-4" */}
            {/*         fill={fill ? "currentColor" : "none"} */}
            {/*         stroke={fill ? "none" : "currentColor"} */}
            {/*         viewBox="0 0 24 24" */}
            {/*       > */}
            {/*         {icon} */}
            {/*       </svg> */}
            {/*     </a> */}
            {/*   ))} */}
            {/* </div> */}
          </div>
        </div>
      </div>
    </section>
  );
}
