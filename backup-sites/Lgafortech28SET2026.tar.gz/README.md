# LgaFortech — recuperação React/Vite

Este projeto foi reconstruído a partir do `index.html` e dos assets enviados.

IMPORTANTE:
- O bundle original que o index.html recuperado usava foi preservado.
- Os outros bundles que estavam misturados no scraping NÃO foram usados.
- Framer Motion já está incluído no package.json.
- Primeiro rode o site recuperado; depois faça a componentização em src/components.

## Rodar

```bash
npm install
npm run dev
```

## Próxima etapa

O objetivo é transformar o bundle recuperado em componentes React editáveis,
sem alterar a cópia original do site.
