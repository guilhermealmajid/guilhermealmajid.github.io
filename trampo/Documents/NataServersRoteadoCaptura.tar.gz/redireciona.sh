#!/bin/bash

# Ativa IP forwarding
echo 1 > /proc/sys/net/ipv4/ip_forward

# Ou para persistir entre reboots:
# sysctl -w net.ipv4.ip_forward=1

# Limpa regras anteriores (opcional)
iptables -t nat -F

# Adiciona regra de redirecionamento de porta 21 para 2121
iptables -t nat -A PREROUTING -p tcp --dport 21 -j REDIRECT --to-port 2121
iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-port 8000
iptables -t nat -A PREROUTING -p tcp --dport 69 -j REDIRECT --to-port 1069

echo "Redirecionamento da porta 21 para 2121 configurado!"

