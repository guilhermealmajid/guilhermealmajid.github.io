from pyftpdlib.handlers import FTPHandler
from pyftpdlib.servers import FTPServer
from pyftpdlib.authorizers import DummyAuthorizer

def iniciar_ftp():
    authorizer = DummyAuthorizer()
    authorizer.add_anonymous('.', perm='elradfmwMT')

    handler = FTPHandler
    handler.authorizer = authorizer

    server = FTPServer(('0.0.0.0', 2121), handler)
    print("FTP anônimo rodando na porta 2121")
    server.serve_forever()

if __name__ == "__main__":
    iniciar_ftp()
