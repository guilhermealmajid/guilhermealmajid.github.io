wf-recorder -f output.mkv
ffmpeg -i output.mkv -movflags +faststart -pix_fmt yuv420p -c:v libx264 -profile:v baseline -level 3.0 -preset veryfast -crf 23 -c:a aac -b:a 128k -ar 44100 gravação-whatsapp.mp4
