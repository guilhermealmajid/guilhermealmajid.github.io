### em outro terminal ###
tail -f saida.log


{ cat /dev/ttyUSB0 > saida.log & reader=$!; sleep 1; cat <<EOF | awk '{ print $0 "\r" }' | pv -qL 20 > /dev/ttyUSB0; sleep 6; kill $reader; pkill $reader; pkill cat }
terminal length 0
show running-config
EOF
