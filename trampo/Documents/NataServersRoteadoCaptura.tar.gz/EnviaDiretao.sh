sudo -S <<< admin ./redireciona.sh
source venv/bin/activate
python serverFTP.py &

serial_port="/dev/ttyUSB0"
cat <<EOF | awk '/^show / || /^configure/ || /^hostname/ || /^exit$/ {print $0 "\r"; next} {print}' | pv -qL 20 > "$serial_port"
format flash:



tclsh
puts [open "nvram:dois" "w+"] "version\n!\nend"
tclquit
configure replace nvram:dois force
!
!
!
!
!
!
!
!
! ### ROTEADOR TA ZERADO ###
!
! //CONFIGURE REPLACE - MAN :)
!
!
configure terminal
!
hostname ALTERADO
!
username EBT privilege 10 password 0 CQMR
!
enable secret PRO1AN
!
interface  GigabitEthernet 0/1
no shutdown
speed 100
duplex full
!
ip address 192.168.1.2 255.255.255.252
!
ip route 0.0.0.0 0.0.0.0 9.9.9.8
!
line vty 0 4
login local
transport input telnet
!
end
!
write
!
!
terminal length 0
!
show runn

copy ftp://192.168.1.1/c1900-universalk9-mz.SPA.151-4.M3.bin flash:/
!
conf t
boot system flash c1900-universalk9-mz.SPA.151-4.M3.bin
!
end
!
wr
!
show version | include .bin
!
show running | include boot system
!
EOF


