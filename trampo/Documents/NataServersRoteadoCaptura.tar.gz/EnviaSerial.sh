#!/bin/bash
#Posso abrir MINICOM e ver input de config deste comando

serial_port="/dev/ttyUSB0"

# Envia comandos para a porta serial
cat <<EOF > $serial_port
configure terminal
hostname  ZEPEQUENO
exit
show running-config
EOF
