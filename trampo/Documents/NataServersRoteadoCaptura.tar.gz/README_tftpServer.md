import tftpy
import os

# Caminho onde os arquivos ficam disponíveis
tftp_root = "."
os.makedirs(tftp_root, exist_ok=True)

# Inicializa o servidor na porta padrão TFTP 69
server = tftpy.TftpServer(tftp_root)
print(f"TFTP Server rodando em modo anônimo, raiz: {tftp_root}")
server.listen('0.0.0.0', 1069)

IP_ADDRESS=192.168.1.2
IP_SUBNET_MASK=255.255.255.0
DEFAULT_GATEWAY=192.168.1.1  
TFTP_SERVER=192.168.1.1
TFTP_FILE=c1900-universalk9-mz.SPA.151-4.M3.bin
tftpdnld
